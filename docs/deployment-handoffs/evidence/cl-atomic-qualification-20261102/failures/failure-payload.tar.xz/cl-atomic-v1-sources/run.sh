#!/usr/bin/env bash
# Focused local measurement only. No identity, signing, network or deployment.
set -euo pipefail
cd "$(dirname "$0")/../.."
profile="${1:?existing profile required}"
filter="${2:?specific test filter required}"
run="${3:?fresh evidence directory required}"
[[ "$profile" == internal-policy || "$profile" == captured-network-diagnostic ]]
[[ ! -e "$run" ]] || { echo "Refusing existing output: $run" >&2; exit 2; }
: "${CL_ATOMIC_BUILD_DIR:?set prepared atomic build directory}"
mkdir -p "$run"
run="$(cd "$run" && pwd)"
build="$(cd "$CL_ATOMIC_BUILD_DIR" && pwd)"
cp ../docs/deployment-handoffs/evidence/cl-resource-decision-refresh-20261102/network-config.json "$run/network-config.json"
python3 scripts/cl_resource_profiles.py "$run/network-config.json" "$run/profile.json" --profile "$profile"
python3 scripts/cl_resource_profiles.py "$run/network-config.json" "$run/setup-profile.json" --profile captured-network-diagnostic
export CARGO_INCREMENTAL=0
export CARGO_NET_OFFLINE=true
export CARGO_TARGET_DIR="$PWD/harness/cl-runtime29/target"
export CL_ARTIFACTS="$build/artifacts"
export AQUARIUS_CONCENTRATED_WASM="$PWD/target/cl-share-checkpoint/aquarius-pool.wasm"
export CL_RESOURCE_PROFILE="$run/profile.json"
export CL_ATOMIC_SETUP_PROFILE="$run/setup-profile.json"
export CL_RESOURCE_REPORT="$run/resources.jsonl"
export CL_CALL_PROFILE_REPORT="$run/calls.jsonl"
export CL_TRANSACTION_REPORT="$run/transactions.jsonl"
: > "$CL_RESOURCE_REPORT"
: > "$CL_CALL_PROFILE_REPORT"
: > "$CL_TRANSACTION_REPORT"
python3 - "$run" "$build" "$filter" <<'PIN'
import hashlib,json,os,sys
from pathlib import Path
out=Path(sys.argv[1]);build=Path(sys.argv[2])
files=[p for p in Path('prototypes/cl-atomic-qualification').rglob('*') if p.suffix in {'.rs','.py','.sh','.patch'}]+list((build/'artifacts').glob('*.wasm'))+list((build/'harness/src').glob('*.rs'))+[build/'build-manifest.json',Path(os.environ['AQUARIUS_CONCENTRATED_WASM'])]
files += [Path('scripts')/n for n in ['check_budget.sh','check_local_budget.py','cl_resource_profiles.py','cl_transaction_evidence.py','decode_cl_transaction_evidence.cjs']]
files=[p for p in files if p.is_file() and '__pycache__' not in p.parts]
(out/'source-before.json').write_text(json.dumps({str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
(out/'run-configuration.json').write_text(json.dumps({'filter':sys.argv[3],'build':str(build),'archive_roles':os.environ.get('CL_TRANSACTION_ARCHIVE_ROLE'),'scope':'controlled-state-compiled-atomic-unsigned','stage1_complete':False,'release_approval':False,'policy_change_implemented':False,'setup':'real calls, captured-network limits enforced; excluded from assessed transactions'},indent=2)+'\n')
PIN
test_status=0
cargo test --manifest-path "$build/harness/Cargo.toml" "$filter" -- --nocapture --test-threads=1 > "$run/tests.log" 2>&1 || test_status=$?
printf '%s\n' "$test_status" > "$run/test-exit-code.txt"
python3 - "$run/source-before.json" <<'PIN'
import hashlib,json,sys
from pathlib import Path
for name,h in json.loads(Path(sys.argv[1]).read_text()).items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h,'Source/artifact changed during run: '+name
PIN
budget_status=0
bash scripts/check_budget.sh --local-report "$CL_RESOURCE_REPORT" --profile "$CL_RESOURCE_PROFILE" --transaction-evidence "$CL_TRANSACTION_REPORT" --gate invocation --summary-json "$run/gates.json" > "$run/budget.log" 2>&1 || budget_status=$?
printf '%s\n' "$budget_status" > "$run/budget-exit-code.txt"
echo "Tests=$test_status; invocation gate=$budget_status. Missing Stage 1 lifecycle/transaction proofs remain failures."
[[ "$test_status" == 0 && "$budget_status" == 0 ]]
