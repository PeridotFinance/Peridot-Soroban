from pathlib import Path
import hashlib,json,tarfile,io,lzma,subprocess,re
root=Path.cwd();out=root/'target/cl-atomic-final-archive';out.mkdir(exist_ok=False)
files={}
def add(name,path):
 path=Path(path);assert path.is_file() and not path.is_symlink(),str(path)
 data=path.read_bytes();assert name not in files,name;files[name]=data
runs={'baseline-live':'cl-atomic-v3-baseline-captured','candidate-live':'cl-atomic-v3-optimized-captured','baseline-restored':'cl-atomic-v4-baseline-archived','candidate-restored':'cl-atomic-v4-optimized-archived','internal':'cl-atomic-v3-baseline-internal','baseline-known-peak':'cl-atomic-v3-baseline-known-peak','candidate-known-peak':'cl-atomic-v3-optimized-known-peak'}
for label,directory in runs.items():
 p=root/'target'/directory
 for f in p.iterdir():
  assert f.is_file() and f.suffix in ['.json','.jsonl','.log','.txt'],str(f)
  add('runs/'+label+'/'+f.name,f)
for name in ['cl-atomic-baseline-v3-build','cl-atomic-optimized-v3-build','cl-atomic-baseline-v4-build','cl-atomic-optimized-v4-build']:
 p=root/'target'/name
 for f in [p/'build-manifest.json',p/'harness/Cargo.toml',p/'harness/Cargo.lock',*sorted((p/'harness/src').glob('*.rs')),*sorted((p/'artifacts').glob('*.wasm'))]:add('builds/'+name+'/'+str(f.relative_to(p)),f)
 if (p/'optimization-build.log').exists():add('builds/'+name+'/optimization-build.log',p/'optimization-build.log')
for p in sorted((root/'prototypes/cl-atomic-qualification').rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts:add('sources/'+str(p.relative_to(root)),p)
pins=json.loads((root/'prototypes/cl-split-transactions/baseline-source-hashes.json').read_text())
for name,h in pins.items():
 p=root/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==h,name
 add('baseline-sources/'+name,p)
add('baseline-sources/source-pins.json',root/'prototypes/cl-split-transactions/baseline-source-hashes.json')
checks=set((root/'scripts').glob('cl_*.py'))|{root/'scripts'/n for n in ['check_budget.sh','check_local_budget.py','decode_cl_transaction_evidence.cjs','make_cl_proof_manifest.py','tests/test_cl_recording_projection.py']}
for p in sorted(checks):add('sources/'+str(p.relative_to(root)),p)
for name in ['scripts/decode_cl_transaction_evidence.cjs','scripts/cl_ci_captures.py']:
 files['original-checker-sources/'+name]=subprocess.check_output(['git','show','90111e2dc1a3cc9ffd941eb3661459e6441e1280:peridot-contracts/'+name])
for p in sorted((root/'target/cl-atomic-final-gate-replay').rglob('*')):
 if p.is_file():add('gate-replay/'+str(p.relative_to(root/'target/cl-atomic-final-gate-replay')),p)
extra=['cl-atomic-final-assessment.json','cl-atomic-measured-details.json','cl-atomic-v3-differential-live-final.json','cl-atomic-v3-differential-known-peak-final.json','cl-atomic-v4-differential-archived.json','cl-atomic-v4-restoration-counts.json','cl-atomic-checker-tests-final.log','cl-atomic-final-review.txt','cl-atomic-v2-review.txt','cl-atomic-independent-review.txt','cl-atomic-restoration-analysis.md','cl-atomic-qualification-report.md','package_cl_atomic_checkpoint.py']
for name in extra:add('analysis/'+name,root/'target'/name)
archive=out/'qualification-payload.tar.xz'
with lzma.open(archive,'wb',preset=3) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|') as tar:
  for name,data in sorted(files.items()):
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
members={name:{'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for name,data in sorted(files.items())}
with tarfile.open(archive,'r:xz') as tar:
 assert set(tar.getnames())==set(members)
 for name,pin in members.items():
  data=tar.extractfile(name).read();assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256']
a=json.loads((root/'target/cl-atomic-final-assessment.json').read_text());replay=json.loads((root/'target/cl-atomic-final-gate-replay/index.json').read_text())
index={'schema':'cl-atomic-qualification-archive-v1','stage1_complete':False,'release_approval':False,'policy_change_implemented':False,'production_source_changed':False,'source_parent':'90111e2dc1a3cc9ffd941eb3661459e6441e1280','atomic_reference':'9cf43082bfb57334d57dbc58cfa90ccad4d98078','negative_split_preserved':'bb154ec8f03889aabfdb8dd5ea120f22c46a47f5','network_sha256':'4102b600e1e910b88b80efb772be4e2d99ad24bf624de1e57250e24daff4f74a','runtime':'SDK/host29.0.1; controlled state, unsigned recording only','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'members':members,'runs':{label:{'original_directory':directory,'test_counts':a['runs'][label]['test_counts'],'original_gates':a['runs'][label]['existing_gates'],'replayed_gates':replay['runs'][label]['actual_summary'],'exact_replay_verified':replay['runs'][label]['all_gate_fields_and_errors_match'],'resolved_projection_errors':len(replay['runs'][label]['expected_removed_old_projection_errors'])} for label,directory in runs.items()},'analysis_only_workload_boundaries':a['boundaries_analysis_only'],'conclusion':'Require storage/read-set/restoration optimization before qualification; isolated TTL patch insufficient. No policy or stage adoption.','missing_signed_authorization':True,'missing_live_state_validation':True,'effective_restored_ttl_for_handled_failures_unqualified':True,'all_member_hashes_verified':True}
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'archive':str(archive),'sha256':index['archive_sha256'],'bytes':index['archive_bytes'],'members':len(members),'release_approval':False}))
