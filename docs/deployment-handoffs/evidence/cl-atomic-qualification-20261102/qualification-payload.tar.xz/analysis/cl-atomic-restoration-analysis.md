# Archived funded-liquidation footprint: v1 diagnostic

This is a read-only analysis of the preserved v1 controlled-state archive run, not a final qualification result. No contracts, policy, stages, tests or operational settings were changed. Final v3 uses corrected fixture/transaction-boundary instrumentation and explicit TEST ONLY reserve configuration; its results must supersede this diagnostic for acceptance.

## Evidence and counting

Input: `target/cl-atomic-baseline-archived/transactions.jsonl`, line 7 (first maximum-write row), test `test::atomic_qualification::atomic_qualification_8_independent_liquidations_repeated_both_call_outages`, flow `liquidate_funded_v3`, ledger 160, captured-network-diagnostic profile. All 8 liquidation records succeed in the unsigned host execution, with 103–104 RW keys and 78–85 restored entries. Line 7 is representative of the seven rows with 104 RW / 85 restored keys; it is not the maximum-CPU row.

| Measurement | Representative row |
|---|---:|
| Instructions | 104,648,399 |
| Memory bytes | 13,358,449 |
| Unique read-only footprint keys | 52 |
| Unique read-write footprint keys | 104 |
| Total unique transaction footprint keys | 156 |
| Restored RW entry indices | 85 |
| Other RW keys | 19 |
| Disk-read bytes | 12,420 |
| Write bytes | 17,048 |
| Unsigned envelope bytes | 14,780 |
| Inclusion / non-refundable / refundable / rent stroops | 100 / 270,573 / 5,049 / 22,716,742 |
| Total estimated fee stroops | 22,992,464 |

The 104 value comes from the actual transaction RW footprint, not summed SDK call-entry counters. The 85 restorations are decoded from `restored_rw_entry_indices` into that exact RW array. The much larger `archive.modified_keys` list describes archive candidates; it is **not** the set actually restored and was not used to count the table below. A restored entry can also be logically changed; the 19 other RW keys are not the complete logical mutation count. Missing-key removal probes can also appear in a footprint.

Archive roles were `vault,cash_receipt,share_receipt,v3,aquarius,lending_controller`. `archive.return_matches_baseline=true`, but the legacy `archive.contract_changes_match_baseline=false` on all eight rows. Therefore this report makes no assertion of archive semantic equivalence. The newer logical-state/TTL comparison is required. Signed-account verification costs remain unmeasured; unsigned simulation does not prove account-signature behavior.

## Actual restored keys

| Role | Restored RW | Other RW | Total RW |
|---|---:|---:|---:|
| Share receipt | 25 | 2 | 27 |
| Cash receipt | 25 | 0 | 25 |
| Lending controller | 13 | 0 | 13 |
| Share vault | 13 | 8 | 21 |
| Margin V3 | 8 | 6 | 14 |
| Aquarius | 1 | 0 | 1 |
| Underlying SAC | 0 | 2 | 2 |
| External authorizer nonce | 0 | 1 | 1 |
| **Total** | **85** | **19** | **104** |

The receipt contracts share these 21 restored keys: `AccumulatedInterest`, `Admin`, `AdminFeeScaled`, `BorrowCap`, `BorrowIndex`, `BorrowYearlyRateScaled`, `CollateralFactorScaled`, `InitialExchangeRate`, `Initialized`, `LastUpdateTime`, `ManagedCash`, `MarginController`, `Peridottroller`, `ReserveFactorScaled`, `SupplyCap`, `TotalAdminFees`, `TotalBorrowed`, `TotalDeposited`, `TotalReserves`, `UnderlyingToken`, `YearlyRateScaled`.

Share receipt additionally restores the margin controller's and liquidator's `Balance` and `HasBorrowed` entries (4). Its other RW keys are the controller's one-shot `MarginWithdrawBypassV2` and contract instance. Cash receipt additionally restores `InterestModel`, `MarginBorrowPrincipal(2)`, `MarginBorrowSnapshots(2)` and `MarginHasBorrowed(2)` (4).

Lending controller restores `Admin`, `CloseFactorScaled`, `LiquidationFeeScaled`, `LiquidationIncentiveScaled`, `Oracle`, `OracleMaxAgeMultiplier`, `PauseLiquidation`, `PauseRedeem`, `SupportedMarkets`, plus two `PriceCache` and two `SupportedToken` entries. The persisted V3 per-position incentive/maintenance terms are used in this flow; the controller's global liquidation settings must be distinguished from those per-position terms when auditing whether a particular global read is necessary.

Share vault restores two each of `Allocation`, `Beneficial`, `HistoryCount`, `HistoryWeight` and `Holder`, plus one `Registered`, one `Shares` and one custody `Total`. Its other RW keys are two `Boundary`, one `HistoryInterval`, two `HistorySegment`, two new `HistoryWeight` and the instance. These are evidence of claim-first historical ownership bookkeeping, not a list of expendable maintenance keys. Do not remove them or prune unresolved claims to fit a budget.

V3 restores `Peridottroller`, `PerpsPositionData(2)`, `Position(2)`, `PositionCollateralVault(2)`, `PositionDebtVault(2)`, `PositionMode(2)`, `PositionPositionVault(2)` and the borrower's `UserPositions`. Its other RW keys are position-specific `PendingLiquidation`, `PendingPerpsClose`, `PendingPerpsCloseRemainder`, `PendingPerpsOpenExecution`, `PendingPerpsOpenPosition` and `PerpsFeeTerms`. Aquarius restores the share vault's `User` entry, intentionally corrupted by the controlled both-call outage fixture. This is not live venue state.

## Why these entries are touched

The captured call tree runs both receipt `get_margin_controller` calls, both policy pause checks, cash and share `update_interest`, cash debt read, two fresh `cache_price` calls with real oracle reads, share exchange-rate read, full cash repayment with transfer/refund, debt-zero assertion, share receipt balance reads, reward reassignment setup, guarded receipt transfer, and the CL custody/reward hook. The latter attempts actual Aquarius claim and pending-view reads despite the controlled outage. Atomic debt repayment and collateral delivery must stay together.

`contracts/receipt-vault/src/storage.rs:128` calls both `bump_core_ttl` and `bump_borrow_state_ttl` inside `ensure_initialized`. The core sweep (`:203`) probes/extends governance, cap, collateral, routing, reserve, fee and optional strategy fields. The interest sweep (`:363`) touches global rate/index/totals fields. `receipt-vault/src/contract.rs:2933` also explicitly runs both sweeps at `update_interest`, even when initialization is not the caller. `repay_full_for_margin` (`:4369`) initializes, updates interest and checks the position debt again. Receipt transfer initializes and updates interest, consults controller health/pause state, then performs custody reassignment and token/reward updates. Thus making only a quote getter cheaper does not remove the same keys subsequently touched by repayment or transfer.

The existing `ensure_initialized_for_snapshot` (`storage.rs:151`) and targeted valuation TTL helpers demonstrate an operation-specific pattern. They do not by themselves fix the mutation flow's broad initialization/interest sweeps. The baseline 9cf source independently confirms that `update_interest` calls both sweeps; no claim here depends on a later getter optimization being present in its WASM.

`contracts/simple-peridottroller/src/storage.rs:121` sweeps `Admin`, `SupportedMarkets`, `Oracle`, `CloseFactorScaled`, `LiquidationIncentiveScaled`, `LiquidationFeeScaled`, `OracleMaxAgeMultiplier` and optional other global fields. Many public policy/price/account-health entrypoints invoke it. Existing pause TTL maintenance is already lazy by pause kind; the observed `PauseLiquidation` and `PauseRedeem` checks are real required checks, not unrelated borrow-pause restoration.

V3 already has a targeted `bump_peridottroller_ttl` helper alongside its broad core helper (`helpers.rs:934`). The observed restored V3 config is only `Peridottroller`, so receipt and lending-controller global sweeps are the first concrete target, not an assumed broad V3 config sweep. Per-position state fragmentation is a separate possible schema change.

## Concrete architecture target, without an asserted saving

To meet the separately discussed Option 1 workload bound of 80 writes, this exact diagnostic would need **at least 24 fewer unique RW keys**, before allowing for different final-v3 reserve settings or larger state. The unchanged internal policy of 50 writes would require at least 54 fewer. These are arithmetic gaps, not predictions. Network allowance of 200 writes does not approve either internal proposal.

1. **Narrow receipt mutation read sets.** Introduce operation-specific initialization/auth, interest, cash-repayment and collateral-transfer storage accessors that maintain only keys actually consumed by the operation. Audit every descendant call, not only the root. Explicit candidate maintenance-only reads include `Admin` and `SupplyCap` on both receipts and unconditional `CollateralFactorScaled` on debt repayment or debt-free transfers. Verify all branches before removing any access: collateral factor is required when transfer health checks need it, `BorrowCap` is required for principal-accounting updates on repayment, reserve/admin factors are required for nonzero interest, and optional strategy/cash paths cannot be silently dropped. Continue initialization, controller identity, live interest accrual, fresh valuation, pauses, reserve accounting and exact transfer checks. This target needs operation-specific TTL/archival tests, including nonzero interest and nonzero borrow caps.

2. **Narrow controller reads.** Make pause/price/support/health entrypoints maintain their exact relevant configuration, rather than global governance/liquidation defaults via `bump_core_ttl`. Keep the actual liquidation/redeem pause checks, oracle freshness/decimals/resolution, support checks and account-health checks. Sweep-only `Admin` and unrelated global incentive/fee/close-factor fields are candidates for elimination, but full call-tree review and measured missing-key proof must establish absence. A real required read elsewhere still restores the key.

3. **If narrow read sets leave the 24-key gap unresolved, compact bounded config/state records.** Candidate schemas: a small versioned receipt identity/routing config separate from rate/fee configuration and mutable interest totals; controller oracle policy separate from governance-only liquidation defaults; a compact V3 position record for mode/vault identities currently stored separately. Keep history/beneficiary records independently addressable and unresolved entitlements retained. Do not put all owners/positions/markets into one growing instance/map. Packing reduces key count only if it replaces old reads; it can increase serialization, bytes, rent, write contention and restoration cost, so no savings are established by this proposal.

4. **Account for migration explicitly.** A compact-schema rollout must pin receipt/controller/V3 ABI and storage versions, restore and validate old values, write the new record, and atomically record which schema is authoritative. Partial migration must not yield mixed defaults, stale identity, stale risk terms or inaccessible positions. A compatibility fallback that reads both schemas increases the cold footprint. Measure migration plus worst first-use cost; do not pretend a separate migration or keepalive moves that cost away. Migration should be bounded per contract/position, preserve debt and reward ownership, and keep legacy funded recovery/full repayment available through the transition. Existing positions cannot be made ineligible for recovery merely because they exceed a new admission workload.

Removing repeated `extend_ttl` calls for the **same** entry may reduce instruction/host-call cost, but cannot reduce unique footprint keys if at least one required read/write/extension still touches that entry. Repeated reads are already deduplicated in the transaction footprint. The needed write reduction requires eliminating a whole entry from the recovery read set or changing its storage representation; neither can be inferred from SDK entry totals.

Keeping all needed entries live through maintenance may reduce restorations, but it is not a recovery guarantee. Missed maintenance or expiry must remain supported; the sponsor, retention reserve, maintenance fees and restoration fallback must be budgeted. Requiring a borrower/governance pre-step before funded liquidation would weaken availability and is not proposed here.

## Required evidence before any decision

Use final v3 baseline and candidate artifacts with explicit configured reserves, cold archived roles, dynamic interest, all required claim-first calls and both-call outages. Compare decoded unique key sets and logical state/TTL separately. Include residual-collateral cases, zero/nonzero debt elsewhere, borrow caps, pause/reserve shortfall, exited beneficiaries, and atomic rollback when repayment or delivery fails. Remeasure all envelope/auth/fee/restoration components and the receipt transfer/repay/redeem paths; do not replace the old maximum with one favorable warm sample. Preserve required execution even for legacy oversized histories, and keep signed/live-state validation and release approval separate. No policy or stage change is recommended as already qualified.

Provenance SHA256:

```
transactions.jsonl     5afd79cbcc80acb61134a5c31955c777df7977c3b78c94ffbfa9d4dfb7dd7b8b
calls.jsonl            2f435681613b1036f28f9fb09d8205fcb97c762619ef264a6dac62aa622d9a64
source-before.json     512d3765f91b45153b56cada723fff830cc9c3d17defdd905908109629ca427f
run-configuration.json 4391803965fad7a1ac4de5a9cb1862437a449ce6e0b25f8d0b1bd046b3c4b75d
```

The source manifest pins v1 `combined.rs` to `8f11be98c68f479235bc9cf282a6173fa83552d177e8cadfc484399d087b2168`, receipt WASM `db995c2ee1614eb90660c8ab79b0780358ed91e0e686aa1ec1c95dc56cc11f0e`, lending-controller WASM `d24e9b05cfa8d1d438dd58c2dda67c954b1cf80016da7c85e0fbf698ae29d3a2`, V3 WASM `f59f592b1013d4e1ec49975f0cb2bb0ff81e9ab0f88f92bd76c3b7a1d6de7a36`, and share-vault WASM `5e52ff4e87cfc70b8f2ff5839a7625b0ef510d0433806661a41b998805bf4e1f`. No execution was rerun for this report.

## Follow-up: recording-mode placeholder versus deletion

The lead subsequently observed the same comparison failure in v3 and identified the controlled Aquarius `User` fault key as the differing key: live execution has it RO, archival execution has it RW for restoration, with a default-valued change record. This section independently verifies the host-source semantics supporting that diagnosis; it does not relabel the preserved run or claim a new full-row replay.

Source inspected: installed `soroban-env-host-29.0.1/src/e2e_invoke.rs`. At lines 346–373, `add_footprint_only_ledger_changes` explicitly handles a key read only in a handled failing subcall: storage rolls back, but its footprint access remains. The helper creates `LedgerEntryChange::default()`, writes only `encoded_key` and `read_only`, and appends it. Thus its `encoded_new_value=None`, both rent sizes are zero, and `ttl_change=None`. This is a fee/footprint placeholder, not a statement that the pre-existing key was deleted. At lines 950–968 the recording path invokes this helper in shadow mode after producing ordinary changes. The comment explicitly distinguishes this recording-only representation from enforcing-mode behavior.

In contrast, `get_ledger_changes` at lines 249–269 only emits ordinary records for keys present in the final storage map (including mapped deletions), and initializes `ttl_change=Some(...)` for a TTL-bearing key based on key durability. A real contract-data/code deletion therefore still has a TTL descriptor even if its new value is absent. An ordinary temporary-entry record can have zero old size after expiration (lines 285–297), so **zero old size alone is not a deletion/placeholder discriminator**. Restored ordinary records can also reset old size and old TTL to zero (lines 328–337).

The current exporter in `target/cl-atomic-baseline-build/harness/src/transaction_evidence.rs:511–529` applies every non-RO record with absent new value as a removal from `full_after`. Its partial post-state calculation at lines 474–495 also omits the prior value for that RW placeholder. Both branches need the same explicit classification; fixing only one hash leaves inconsistent evidence.

Bounded proposed classifier, pinned to host 29.0.1 recording-mode output:

```
is_footprint_only_contract_placeholder =
    key is ContractData or ContractCode
    AND encoded_new_value is None
    AND old_entry_size_bytes_for_rent == 0
    AND new_entry_size_bytes_for_rent == 0
    AND ttl_change is None
```

For those records, preserve the original logical entry if present, or absence if absent, in both full and partial post-state maps. Do not mark a contract deletion. Record the classification and the raw change fields. For ordinary RO records, preserve original data and apply separately reported TTL information. For ordinary RW records, apply `encoded_new_value` or an actual deletion. Restrict the classifier to contract data/code; do not generalize to non-TTL ledger keys from this proof. A host version change requires renewed source verification. Unexpected record shapes must fail validation rather than be treated as unchanged.

TTL/restoration needs a distinct treatment: retaining the old logical value does **not** prove that an archived key retains its expired TTL or which restored TTL the network will install. Preserve raw restoration indices and fee inputs unchanged; use the pinned runtime's restoration rules/evidence for restored TTL, or label effective TTL unresolved where the placeholder lacks it. Never manufacture a TTL from a logical-state equality. Final logical-equivalence assertions should compare normalized data for all keys, with TTL/restoration assertions separately defined.

Before publishing corrected results, preserve v3 raw outputs and record the exporter revision. A small focused exporter regression should cover existing-key handled failures in live RO and archived RW forms, absent-key placeholders, successful writes/restoration, genuine deletion with a TTL descriptor, and top-level rollback. Where possible, compare enforcing-mode ledger changes for the same unsigned invocation as an independent confirmation; this still does not measure real account signatures. Corrected replay must report exact changed semantic flags and unchanged resource/fee fields. This diagnostic's 104 RW keys remain present in the actual resource footprint even if a placeholder is correctly excluded from logical deletions; the write-workload failure does not disappear.
