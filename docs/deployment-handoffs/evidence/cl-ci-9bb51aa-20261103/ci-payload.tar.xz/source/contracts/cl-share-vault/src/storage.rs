use soroban_sdk::{contracttype, Address, Env, Symbol};

/// Pool wiring and the currently active position range.
///
/// Everything here lives in a single **instance** storage entry. That is not a
/// style preference: the market-deposit path spans ReceiptVault -> this vault
/// -> the Aquarius pool -> three token contracts, and Soroban caps a
/// transaction at 100 footprint ledger entries. One entry per config field put
/// the end-to-end deposit at 113 and made it unexecutable on-chain.
#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Config {
    pub pool: Address,
    pub token0: Address,
    pub token1: Address,
    pub dec0: u32,
    pub dec1: u32,
    pub underlying_index: u32,
    pub tick_lower: i32,
    pub tick_upper: i32,
    pub oracle: Address,
}

/// Admin-tunable risk parameters. Also a single instance entry.
#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Params {
    /// Cap on underlying deployed into the pool; 0 disables it.
    pub max_deploy: u128,
    pub slippage_bps: u32,
    pub harvest_cooldown: u64,
    pub oracle_max_age_mult: u64,
    /// How long a cached NAV root stays usable without re-reading the oracle.
    ///
    /// This is a footprint budget decision as much as a freshness one: the
    /// ReceiptVault withdraw path already spans six contracts, and pulling two
    /// Reflector prices inside it pushed the transaction over Soroban's
    /// 100-entry cap. The ratio being cached is between two pegged assets, so
    /// it moves slowly; `refresh_nav_root()` forces an update out of band.
    pub nav_root_max_age: u64,
    /// Maximum tolerated gap between the pool's own swap quote and the
    /// oracle-implied fair rate, in basis points. `0` disables the check.
    ///
    /// The per-swap slippage floor is derived from `estimate_swap`, so it only
    /// guards against movement between quote and execution — it cannot tell
    /// that the pool itself is mispriced. Entering or exiting through a
    /// dislocated pool can realize that gap immediately: on testnet a ~7%
    /// pool/oracle divergence cost 4.65% of a deposit. This guards both
    /// position entry and the paired-token leg of position exit.
    pub max_pool_divergence_bps: u32,
    /// Hard ceiling on how old the cached NAV root may be when the oracle is
    /// unreachable. Past this the vault refuses to price rather than serving an
    /// arbitrarily obsolete ratio. `0` disables the bound.
    pub nav_root_max_stale: u64,
    pub paused: bool,
}

/// Mutable global accounting. Also a single instance entry.
#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct State {
    pub total_shares: u128,
    pub position_liquidity: u128,
    /// Last good `sqrt(other_price / underlying_price)`, 1e9-scaled.
    pub last_nav_root: u128,
    pub last_nav_root_at: u64,
    pub last_harvest: u64,
}

/// Last observed token amounts backing the active concentrated position.
///
/// Unlike a full-range position, concentrated-liquidity NAV cannot be derived
/// from liquidity alone: its token mix changes as pool price moves through the
/// configured range. The keeper refreshes this snapshot from Aquarius and all
/// position mutations update it from actual token balance deltas.
#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PositionAmounts {
    pub liquidity: u128,
    pub amount0: u128,
    pub amount1: u128,
    pub updated_at: u64,
}

/// Keeper-managed range policy. Stored outside `Config` so an upgrade can
/// decode the exact Config value already present on Mainnet.
#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RangeParams {
    /// Requested distance from the center to either edge, in raw ticks.
    /// Bounds are rounded outward to the pool's tick spacing.
    pub half_width_ticks: u32,
    /// Recenter when spot enters this many ticks of either edge.
    pub rebalance_margin_ticks: u32,
    pub rebalance_cooldown: u64,
    /// Independent, tighter pool/oracle guard used only for recentering.
    pub max_rebalance_divergence_bps: u32,
    pub enabled: bool,
}

#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RangeState {
    pub last_rebalance_at: u64,
}

#[contracttype]
pub enum DataKey {
    // instance
    Config,
    Params,
    State,
    Admin,
    Initialized,
    // persistent
    PendingAdmin,
    PendingUpgradeHash,
    PendingUpgradeEta,
    Shares(Address),
    RewardRoute(Address),
    OracleSymbol(Address),
    // Keep new variants at the end and outside Config so upgrading an existing
    // testnet deployment does not invalidate its serialized Config value.
    ReceiptVault,
    PrimaryRewardToken,
    RewardMinRate(Address),
    // Concentrated-range upgrade state. Append only: these variants were
    // added after the first Mainnet full-range deployment.
    PositionAmounts,
    RangeParams,
    RangeState,
}

const TTL_THRESHOLD: u32 = 500_000;
const TTL_EXTEND_TO: u32 = 1_000_000;
const SHARE_TTL_EXTEND_TO: u32 = 5_000_000;
/// Renew only when the entry is genuinely close to expiring (~58 days left).
/// A threshold near `SHARE_TTL_EXTEND_TO` would re-bump on essentially every
/// read, and the resulting rent charge pushed the market's withdraw path over
/// its per-transaction resource limits.
const SHARE_TTL_THRESHOLD: u32 = 1_000_000;

/// One `extend_ttl` covers Config, Params, State and Admin together.
pub fn bump_critical_ttl(env: &Env) {
    env.storage()
        .instance()
        .extend_ttl(TTL_THRESHOLD, TTL_EXTEND_TO);
}

pub fn bump_share_ttl(env: &Env, owner: &Address) {
    let key = DataKey::Shares(owner.clone());
    if env.storage().persistent().has(&key) {
        env.storage()
            .persistent()
            .extend_ttl(&key, SHARE_TTL_THRESHOLD, SHARE_TTL_EXTEND_TO);
    }
}

pub fn bump_pending_admin_ttl(env: &Env) {
    let key = DataKey::PendingAdmin;
    if env.storage().persistent().has(&key) {
        env.storage()
            .persistent()
            .extend_ttl(&key, TTL_THRESHOLD, TTL_EXTEND_TO);
    }
}

pub fn bump_pending_upgrade_ttl(env: &Env) {
    let p = env.storage().persistent();
    for key in [DataKey::PendingUpgradeHash, DataKey::PendingUpgradeEta] {
        if p.has(&key) {
            p.extend_ttl(&key, TTL_THRESHOLD, TTL_EXTEND_TO);
        }
    }
}

pub fn config(env: &Env) -> Config {
    env.storage()
        .instance()
        .get(&DataKey::Config)
        .expect("vault not initialized")
}

pub fn set_config(env: &Env, cfg: &Config) {
    env.storage().instance().set(&DataKey::Config, cfg);
}

/// The only ReceiptVault allowed to add capital. `None` blocks deposits,
/// making the deployment fail closed until the two contracts are bound.
pub fn bound_receipt_vault(env: &Env) -> Option<Address> {
    env.storage().instance().get(&DataKey::ReceiptVault)
}

pub fn set_bound_receipt_vault(env: &Env, receipt_vault: &Address) {
    env.storage()
        .instance()
        .set(&DataKey::ReceiptVault, receipt_vault);
}

/// Primary token paid by Aquarius `claim()`. Gauge rewards are discovered
/// dynamically, but the primary claim ABI returns only an amount, so its token
/// address must be explicit and admin-rotatable.
pub fn primary_reward_token(env: &Env) -> Option<Address> {
    env.storage().instance().get(&DataKey::PrimaryRewardToken)
}

pub fn set_primary_reward(env: &Env, reward_token: &Option<Address>) {
    match reward_token {
        Some(token) => env
            .storage()
            .instance()
            .set(&DataKey::PrimaryRewardToken, token),
        None => env
            .storage()
            .instance()
            .remove(&DataKey::PrimaryRewardToken),
    }
}

pub fn params(env: &Env) -> Params {
    env.storage()
        .instance()
        .get(&DataKey::Params)
        .expect("vault not initialized")
}

pub fn set_params(env: &Env, p: &Params) {
    env.storage().instance().set(&DataKey::Params, p);
}

pub fn state(env: &Env) -> State {
    env.storage()
        .instance()
        .get(&DataKey::State)
        .unwrap_or(State {
            total_shares: 0,
            position_liquidity: 0,
            last_nav_root: 0,
            last_nav_root_at: 0,
            last_harvest: 0,
        })
}

pub fn set_state(env: &Env, s: &State) {
    env.storage().instance().set(&DataKey::State, s);
}

pub fn position_amounts(env: &Env) -> Option<PositionAmounts> {
    env.storage().instance().get(&DataKey::PositionAmounts)
}

pub fn set_position_amounts(env: &Env, amounts: &PositionAmounts) {
    env.storage()
        .instance()
        .set(&DataKey::PositionAmounts, amounts);
}

pub fn range_params(env: &Env) -> RangeParams {
    // Existing full-range deployments deliberately fail closed after the
    // Wasm upgrade. Governance must install a reviewed policy before anyone
    // can migrate their live position.
    env.storage()
        .instance()
        .get(&DataKey::RangeParams)
        .unwrap_or(RangeParams {
            half_width_ticks: 0,
            rebalance_margin_ticks: 0,
            rebalance_cooldown: 0,
            max_rebalance_divergence_bps: 0,
            enabled: false,
        })
}

pub fn set_range_params(env: &Env, value: &RangeParams) {
    env.storage().instance().set(&DataKey::RangeParams, value);
}

pub fn range_state(env: &Env) -> RangeState {
    env.storage()
        .instance()
        .get(&DataKey::RangeState)
        .unwrap_or(RangeState {
            last_rebalance_at: 0,
        })
}

pub fn set_range_state(env: &Env, value: &RangeState) {
    env.storage().instance().set(&DataKey::RangeState, value);
}

pub fn admin(env: &Env) -> Address {
    env.storage()
        .instance()
        .get(&DataKey::Admin)
        .expect("admin not set")
}

pub fn shares_of(env: &Env, owner: &Address) -> u128 {
    env.storage()
        .persistent()
        .get(&DataKey::Shares(owner.clone()))
        .unwrap_or(0u128)
}

pub fn set_shares(env: &Env, owner: &Address, amount: u128) {
    let key = DataKey::Shares(owner.clone());
    if amount == 0 {
        env.storage().persistent().remove(&key);
    } else {
        assert!(amount >= 100, "remaining share balance below minimum");
        env.storage().persistent().set(&key, &amount);
        bump_share_ttl(env, owner);
    }
}

/// Renews a configured-mapping key. Uses the same low threshold as share
/// renewal so it only writes when the entry is genuinely near expiry —
/// a high threshold re-bumps on every read, and the rent charge is what
/// pushed the market's withdraw path over its resource limits.
pub fn bump_mapping_ttl(env: &Env, key: &DataKey) {
    if env.storage().persistent().has(key) {
        env.storage()
            .persistent()
            .extend_ttl(key, SHARE_TTL_THRESHOLD, SHARE_TTL_EXTEND_TO);
    }
}

/// Reads a token's Reflector symbol override, renewing it on the way past.
///
/// This mapping is on the critical path: without it `nav_root` cannot price
/// the pair, and a fault there blocks both deposits *and* withdrawals. It is
/// also mandatory wherever the feed publishes `Other(Symbol)` assets rather
/// than `Stellar(Address)` — which is the case on testnet for both tokens —
/// so letting it archive would strand the market.
pub fn oracle_symbol(env: &Env, token: &Address) -> Option<Symbol> {
    let key = DataKey::OracleSymbol(token.clone());
    bump_mapping_ttl(env, &key);
    env.storage().persistent().get(&key)
}
