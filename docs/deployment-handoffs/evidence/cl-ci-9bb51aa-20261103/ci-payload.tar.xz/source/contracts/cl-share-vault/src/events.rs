use soroban_sdk::{contractevent, Address, Symbol};

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct VaultInitialized {
    pub admin: Address,
    pub pool: Address,
    pub underlying: Address,
    pub tick_lower: i32,
    pub tick_upper: i32,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Deposited {
    pub from: Address,
    pub underlying_in: u128,
    pub liquidity_minted: u128,
    pub shares_minted: u128,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Withdrawn {
    pub to: Address,
    pub shares_burned: u128,
    pub liquidity_burned: u128,
    pub underlying_out: u128,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Harvested {
    pub caller: Address,
    pub reward_token: Address,
    pub reward_amount: u128,
    pub underlying_out: u128,
}

/// Emitted when a harvest leg is skipped rather than reverting the whole call.
/// A single unsellable reward token must not block the rest of the harvest.
#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HarvestSkipped {
    pub reward_token: Address,
    pub reward_amount: u128,
    pub reason: Symbol,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExternalCallFailed {
    pub contract: Address,
    pub function: Symbol,
    pub recoverable: bool,
    pub failure_kind: u32,
}

/// Raised when liquidity was burned but no underlying came back. Emitting
/// instead of panicking keeps withdrawals from being DoS'd by a misbehaving
/// pool, matching `receipt-vault`'s `BoostedRedeemZeroReturn` handling.
#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RedeemZeroReturn {
    pub liquidity_burned: u128,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdminTransferProposed {
    pub current_admin: Address,
    pub pending_admin: Address,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdminTransferred {
    pub previous_admin: Address,
    pub new_admin: Address,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ConfigChanged {
    pub what: Symbol,
    pub old_value: u128,
    pub new_value: u128,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PausedSet {
    pub paused: bool,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReceiptVaultBound {
    pub receipt_vault: Address,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PrimaryRewardTokenSet {
    pub reward_token: Option<Address>,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RangePolicySet {
    pub enabled: bool,
    pub half_width_ticks: u32,
    pub rebalance_margin_ticks: u32,
    pub rebalance_cooldown: u64,
    pub max_rebalance_divergence_bps: u32,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PositionRebalanced {
    pub caller: Address,
    pub old_tick_lower: i32,
    pub old_tick_upper: i32,
    pub new_tick_lower: i32,
    pub new_tick_upper: i32,
    pub liquidity_burned: u128,
    pub liquidity_minted: u128,
}

/// SEP-41 approval event. Approvals do not checkpoint or transfer rewards.
#[contractevent(topics = ["approve"], data_format = "vec")]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ShareApproval {
    #[topic]
    pub from: Address,
    #[topic]
    pub spender: Address,
    pub amount: i128,
    pub expiration_ledger: u32,
}

/// The legacy scalar SEP-41 transfer event is accepted by existing consumers.
#[contractevent(topics = ["transfer"], data_format = "single-value")]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ShareTransfer {
    #[topic]
    pub from: Address,
    #[topic]
    pub to: Address,
    pub amount: i128,
}
