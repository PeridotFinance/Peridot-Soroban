# Split prototype: independent accounting and recovery review

2026-11-02. Design for an explicitly requested isolated local prototype; not a
production stage change or approval. The existing baseline remains intact. No
resource limits, shared policy, borrowing enablement, Mainnet guards, signing,
broadcasting, or production configuration are changed by this analysis.

## Decision

Separating `claim_all_position_fees` from `deposit_position` is worth measuring,
but a previous fee collection is not evidence that a later share mint has a
fee-inclusive price. The pool permits intervening swaps; the entrant's own
balancing swap also earns fees for the incumbent LP position.

The smallest correctness probe is a separate incumbent fee collection followed
by the existing atomic mint/transfer/custody path, replacing its collection only
when an authentic same-invocation fee view proves that nothing claimable remains.
That probe does not appear sufficient for the internal CPU cap under the measured
call decomposition. A useful next candidate moves the entrant's conversion into
segregated, cancellable escrow, then checkpoints incumbent fees, then performs a
freshly priced balanced deposit plus **all three existing claim-first boundaries
atomically**. Its resource feasibility is unproven, and must be measured rather
than inferred from the old whole-transaction total.

Do not split immediately after minting shares to the existing facade. The facade
is not a registered custodian: while it holds shares it is their direct reward
beneficiary. A multi-ledger gap before transfer/custody assignment would assign
emissions to the facade instead of the position owner. An ownership lock does
not repair this, and must not block other holders' forced exits.

## What the current code actually does

`cl-share-vault::deposit` currently:

1. Authenticates the depositor, enters the accounting guard, and calls
   `rewards::normal` before changing supply/ownership.
2. Calls `collect_fees`, which invokes Aquarius `claim_all_position_fees` and
   refreshes the existing position composition with `estimate_withdraw_position`.
3. Values the existing position and both idle assets before incoming money.
4. Transfers the input, swaps part of the vault's underlying, and calls
   `deposit_position`; validates actual spent amounts, reported amounts, and
   minted liquidity.
5. Mints from the measured net value added, resets reward debt, and exits the
   accounting guard.

The facade transfers the new shares to V3, invoking another reward checkpoint;
V3 then assigns beneficial custody, invoking the third checkpoint. These calls
must remain real calls. A reward claim during preparation cannot replace a claim
at a later ownership boundary.

`total_underlying_full` includes paired idle balances but deliberately excludes
uncollected pool trading fees. Thus reusing it after an earlier collection,
without an authentic current fee test, can mint a newcomer against an understated
incumbent NAV. Conservative understatement for a lending quote is not safe pricing
for a new share issuance. Reward-token quarantine remains outside principal NAV;
it must never be included as if it were pool trading fees.

The pinned venue interface exposes
`get_all_position_fees(owner) -> Vec<u128>` and
`claim_all_position_fees(owner) -> Vec<u128>`. Position types also include stored
fee-growth checkpoints and tokens owed. These ABI facts are not yet a proof that
the view equals the collectible balance delta across ticks, rounding, deposits,
partial withdrawals, and archived state. Merely checking tick, price, timestamp,
vault revision, or the vault's last known liquidity cannot detect every pool fee
change. A vault cannot lock permissionless pool trades.

## Two valuation approaches, with separate proof obligations

**Zero-fee fence:** collect before finalization, then in the same invocation as
the final before-NAV read require the exact pinned view to return two zero token
amounts. Reject a nonzero value, malformed vector, wrong code identity, or failed
view. Refresh actual position composition and use a current admissible oracle
ratio. A later failed finalization rolls back its own work; preparation remains
a completed operation owned by existing shareholders. After proving view/claim
equivalence, this is smaller than inventing a fee-inclusive pricing algorithm.
It sacrifices liveness: trades can repeatedly invalidate preparation. Keep retry
and cancellation available; never silently fall back to an unmeasured expensive
collection in the final transaction.

**Fee-inclusive valuation:** use authenticated current collectible token amounts
in NAV at the final ownership boundary instead of demanding zero. This avoids a
trade-induced retry loop but requires a full accounting proof. Include fees once
whether they remain claimable, are paid during a deposit, or become idle. Keep
pre-existing fees separate from the entrant's own swap fees. A naive
`NAV_after - NAV_before` that newly includes fees earned by incumbent liquidity
during the entrant's swap can credit that entrant for value earned by incumbent
capital. Decide and test the exact entry-cost allocation; do not change the
current mint economics accidentally through inconsistent before/after views.
If the venue can automatically pay fees during `deposit_position`, reconcile
actual token deltas and the change in the outstanding fee claim, with no double
count. This alternative is larger and not the first safe prototype.

For the first zero-fee prototype, compare against the existing collection path
at exactly the same pre-state and inputs. A zero raw-token view must predict zero
actual collectible token deltas; account for scaled fractional fee growth that
can later round into a token. Show that the normal path's collection does not
make a non-equivalent persistent fee checkpoint that changes later entitlement.
A successful comparison in one empty-fee state is insufficient.

## Smallest candidate with a plausible CPU budget

The following are proposed prototype operations, not existing ABI names.

| State / operation | Assets and ownership | Allowed transition / recovery |
| --- | --- | --- |
| No intent | All principal remains with its current owner; no new shares/debt. | Owner creates one nonce-bound intent with exact assets, amounts, beneficiary, destination, price/slippage floors, and deadline. |
| Funded escrow / conversion | A separate escrow owns only this intent's identified principal. It may hold underlying and paired tokens; both belong economically to that owner. They are excluded from the shared vault NAV and share rewards. | Convert under exact bounded authorization and fresh price/slippage checks. Cancellation returns the exact two-asset balances in kind, independent of pool claim/view availability. No promise of converting back to the original underlying amount. |
| Incumbent fee preparation | Collection moves already-owned LP fees into the shared vault's idle balances and refreshes composition. It does not mint shares, borrow, or transfer escrow ownership. | Preparation may be repeated; it does not grant a transferable price ticket. No separate user refund is owed for fees collected for incumbent shareholders. |
| Atomic balanced finalization | Recheck nonce/state/deadline/pauses and current code identity, prove zero pending trading fees, refresh incumbent composition and current supply/NAV, claim rewards before mint, transfer only intent-bound assets, perform balanced position deposit, validate actual deltas, mint by net value, transfer shares, assign custody with both subsequent real claims. | Commit once only if every step and output floor succeeds. Otherwise the whole final transaction rolls back to the original escrow state. |
| Completed | New shares have their final intended physical and beneficial owner; any unused escrow residue is explicitly either returned or included in the measured minted value. | Existing transfer, close, full-repayment/release and funded liquidation semantics apply. Repeating finalization rejects. |
| Expired/cancelled | No newly minted shares; existing holders' principal/rewards unchanged except legitimate pool trading fees earned during conversion. | Return in-kind escrow assets to the bound owner; consume the intent once. Do not require governance attribution or a reward waiver. |

Preparation must follow conversion for the zero-fee candidate, because conversion
itself can add trading fees to the incumbent position. An intervening external
swap between preparation and finalization invalidates the zero-fee fence. If
that happens, repeat collection and finalization or cancel in kind. All checks
and retry costs remain inside measured invocations.

Use a separate escrow contract or an equally explicit asset-accounting partition.
Simply leaving unminted assets in the current shared vault is unsafe: its balance
reads and emergency pro-rata withdrawal logic treat them as common backing.
Per-intent accounting must also distinguish donated dust from the owner's assets.
Do not sweep another intent, a donation, or pre-existing vault dust into a refund
or the new deposit's measured value added.

The final deposit must value all incumbent backing, including both idle assets,
before admitting escrow assets. Prefer offering only the intent's bounded assets
to the new balanced LP deposit; leave unrelated idle capital owned by incumbent
shares. Any alternative that co-deploys old idle assets must prove that its costs
and residual assets cannot subsidize or overcharge the entrant. Supply, liquidity,
composition, and oracle valuation are reread at finalization, not taken from an
old ticket. Current holders can transfer or exit between stages; minting must use
the actual resulting supply and NAV. If the last holder exited, apply the existing
zero-supply/unowned-NAV rule instead of adopting abandoned assets.

### Borrowed funds are a separate expansion

The smallest useful accounting/resource experiment is owner-funded and creates
no debt before finalization. It does not establish a leveraged opening path.
The current V3 cannot simply pretend that an escrow conversion is its existing
atomic `swap_open_position_v3`.

If a subsequent prototype funds escrow with a V3 draw, it introduces live debt
before shares exist. It must define collateral control for both escrow tokens,
interest accrual, deadline, output valuation, permissioned completion, retries,
and fully funded recovery for **every** intermediate state. Cancellation cannot
release borrowed capital with debt outstanding. Owner-funded full repayment plus
release of the entire remaining escrow must be atomic; permitted liquidator
repayment and bounded seizure must also be atomic, with any surplus returned.
Those routes must work while origination is paused or cash reserves are short.
Fresh reserve enforcement after final open costs remains mandatory before
activation. Do not add a fast cancellation route that bypasses debt or a global
lock that prevents existing forced recovery.

## Resource assessment: hypotheses, not substitute measurements

From the preserved measured swap-open decomposition, the Aquarius subtrees cost:

| Subtree | Instructions |
| --- | ---: |
| Initial reward claim | 6,598,979 |
| Position fee collection | 53,570,569 |
| Existing composition estimate | 4,772,699 |
| Swap estimate / swap | 8,808,917 / 10,955,817 |
| Balanced deposit estimate / deposit | 4,543,019 / 64,865,976 |
| Transfer reward claim / custody reward claim | 5,973,639 / 5,968,733 |

Removing fee collection alone leaves these named retained subtrees at about
112.49M instructions, already above 100M before their remaining wrappers. This is
a specific lower-bound observation for that decomposition, not proof that every
split fails. Separating conversion and its quote as well leaves about 92.72M in
the named final deposit/claims/valuation subtrees. Fee-view checks, escrows,
authorization, fresh configuration, serialization, all hooks, and transaction
overhead still have to be added and measured; duplicated work may eliminate the
remaining space. Neither number is a completed-flow measurement or headroom.

Measure each prototype operation with the unchanged internal profile and the
captured-network diagnostic, plus the actual target-runtime unsigned transaction
path. Report SDK entry totals separately from unique footprint keys. Include
minimum/maximum supported histories, repeated outages, restored dependencies,
ticks/ranges, zero/nonzero pending fees, stale/failing views, rollback, and retry
cost. Signed-transaction costs remain a separate missing gate. No aggregate
failure, byte-size estimate, or subtraction can replace these measurements.

If the final three-boundary group still exceeds policy, splitting share custody
is a different architecture requiring an escrow beneficiary at the instant of
mint. Current `custody_assign` introduces its own actual claim-first call, so
adding such ownership may add a fourth claim to measure. Do not bypass it or
let shares sit in unassigned custody and quietly quarantine rewards that should
belong to the depositor. Keep this as an explicit later alternative.

## Required adversarial proofs

1. **Venue fee-view equivalence:** use actual pinned Aquarius bytecode across
   nonzero/zero fees, fractional rounding, both swap directions, range crossings,
   outside-range liquidity, emission changes, multiple deposits/partial exits,
   and restored fee/tick state. Compare view with actual token balance delta on
   immediate collection and subsequent accrual; fail on any unproved boundary.
2. **Intervening pool trades:** prepare, externally trade, finalize. The zero-fee
   candidate must reject without consuming escrow, minting, changing debt, or
   reallocating rewards. Repeat preparation and succeed; demonstrate repeated
   griefing still permits exact in-kind cancellation.
3. **Entrant conversion fees:** conversion earns a known fee for incumbent LP
   capital. Preparation after conversion and fresh mint pricing preserve that
   incumbent value; newcomer receives only their net contributed value.
4. **Ownership and custody changes:** transfer, receipt transfer, margin custody
   reassignment, partial/full exit, newcomer entry, and last-holder exit between
   stages. Final price uses current supply/NAV; historical reward conservation
   preserves exited owners and never credits the facade or a newcomer improperly.
5. **Reward outages:** first, second, or third normal claim fails; both claim and
   pending view fail. Finalization rolls back completely. Existing forced exits
   continue to journal/quarantine correctly; pre-mint escrow cancellation does
   not need a reward claim because it has no share entitlement to waive.
6. **Authorization/replay:** wrong owner, controller impersonation, altered nonce,
   beneficiary, recipient, assets, amount, output minimum, or deadline; missing
   nested authorization; concurrent intents; duplicate finalize/cancel/retry.
   Contract authorization is never mocked. Account fixtures remain narrowly
   scoped and do not stand in for production signature proof.
7. **Valuation and pause changes:** oracle failure/staleness, changed pool code,
   fee-view failure, malformed fee vector, changed tick/range, deposit/swap kill,
   borrower pause, reserve shortfall and configuration change. Reject unsafe
   finalization; preserve authorized in-kind/funded recovery.
8. **Rollback and assets:** failed second asset transfer, failed pool deposit,
   mismatched reported spend, insufficient LP output, reward failure after mint,
   or failed share transfer/assignment leaves all relevant pre-state intact.
   Dust cannot be appropriated; residual assets have one explicit owner.
9. **Economic conservation:** same-state baseline comparison, exact scaled reward
   conservation, no incumbent fee dilution, entrant bears conversion costs,
   explicit rounding residuals, replay-zero settlement, and no double counting
   of collected versus pending fees.
10. **Operational failure:** escrow/code/history archival, missing keeper, expired
    pending state, repeated view/claim outages, and unavailable governance
    evidence. No unresolved entitlement is pruned; no recovery requires an
    attribution decision or a blanket global ownership pause.

Until these proofs and per-stage resource measurements exist, the candidate is a
local feasibility experiment. It does not complete Stage 1 or make PR #75 ready
for release.

## Additional review: exact venue witnesses and beneficiary-at-mint escrow

The lead extracted the actual pinned WASM interface to
`target/cl-split-design/aquarius-interface.rs`. It additionally exposes
`get_fee_growth_global_0_x128`, `get_fee_growth_global_1_x128`, `get_position`,
`get_tick`, `get_ticks_batch`, and per-position fee views. The position contains
liquidity, both last-inside-growth checkpoints and both tokens-owed balances;
ticks contain both outside-growth accumulators. These support a stricter
prototype witness without relying on a timestamp.

For a conservative post-collection witness, record the actual pool/code identity,
both global fee-growth values, the vault's owned range set and liquidity, each
range's position fee checkpoints/tokens owed, and a vault mutation revision. At
finalization re-read and compare the complete specified witness. Also require
the current aggregate fee view to be exactly two zero raw-token amounts. Reject
on any mismatch or unavailable field. Fresh current composition, oracle ratio,
actual balances, and share supply are still required: global fee growth can stay
unchanged while price moves through a zero-fee trade or custody/supply changes.
Use a per-job record; a witness is not a global ownership lock.

Global-growth equality is intentionally stronger than necessary. Trading in a
different range can invalidate it despite no new fee for this position; repeated
invalidations are a liveness/fee-cost problem, not grounds to accept stale state.
Do not invent a same-value-after-wrap guarantee without proving the venue's
accumulator arithmetic and admissible bounds. The complete owned-range set must
be bounded for measurement; a single tracked position cannot stand in for all
positions returned by the venue.

The strongest small prototype also compares current position checkpoints and
relevant tick state to the post-collection witness. This can reject more often,
but it avoids inferring inside-range growth from price/global values alone.
Measure its additional read/serialization footprint. A narrower witness is an
optimization requiring proof that every omitted state field cannot alter fees
or principal valuation. Do not use a hand-written reconstruction of fee growth
as authoritative until its exact arithmetic matches the pinned bytecode.

Integer `get_all_position_fees == [0,0]` alone may hide fractional growth below a
token. The differential test must establish what ordinary collection does to
that growth: preserves it, realizes it into an owed integer amount, or discards
it through checkpoint rounding. Compare the candidate and ordinary collection
path through **later** swaps/claims, not only the immediate zero payout. A
post-collection full-growth witness avoids intervening growth but does not by
itself prove that omitting a second zero collection has no rounding-side effect.
If this cannot be established, the fast path is unproved even if its immediate
NAV and CPU look acceptable.

Emission configuration, reward timestamp, and reward pending state are separate
from trading-fee growth. They can change with an otherwise valid trading-fee
witness. Preserve the actual reward claim at each ownership boundary, and test
emission changes during every inter-stage delay.

An explicit registered share escrow can permit delivery in a later transaction,
provided finalization atomically establishes the depositor's beneficial ownership
at mint. With the existing APIs, minting physical shares into registered custody
first creates unassigned shares; `custody_assign` then performs its own real
claim-first boundary. Count and meter that extra claim. Merely writing an intent
whose `owner` field names the depositor does not change the reward ledger's
effective weight. A bespoke beneficiary-aware mint would be a new accounting
operation requiring its own proof that there was one instantaneous ownership
change and no omitted original claim-first boundary.

For the straightforward API-based escrow prototype, maintain the old depositor
beneficiary through delayed escrow→controller movement, using exact scoped
custody preparation and actual transfer authorization. Any temporary unassigned
controller state and its assignment must complete in the same delivery
transaction; otherwise new emissions become unjustifiably quarantined. The
mint-stage extra claim and delivery's original transfer/assignment claims remain
inside measurement. Receipt handoff and future seizure use the established
beneficial-owner hooks. A cancelled post-mint intent must deliver the owned
shares or use a permitted forced recovery transfer with historical preservation;
it cannot claim the pre-mint right to refund the original underlying amount.
If borrowed, debt settlement and any seizure/release remain atomic.

Adversarial additions: delay delivery across multiple reward epochs; fail both
reward claim and pending view before delivery; donate shares to either custodian;
swap recipients/intent nonces; attempt escrow beneficiary reassignment; lose the
original submitter/keeper; expire and restore the intent and custody keys; and
retry failed delivery. Assert rewards follow the original depositor throughout,
never the escrow contract, never unassigned custody by accident, and never a
newcomer. All of these are new obligations; the current facade's atomic roundtrip
does not prove them automatically.
