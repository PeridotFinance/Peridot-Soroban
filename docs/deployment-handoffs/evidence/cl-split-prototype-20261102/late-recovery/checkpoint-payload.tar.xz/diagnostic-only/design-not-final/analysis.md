# Isolated split-transaction prototype: architecture assessment

This is a design for an explicitly authorized local prototype, not a change to production stages, shared policy or resource limits. The 147.9M sum of unchanged venue subcalls is a lower bound for keeping them in **one invocation**, not proof that no transaction split can fit. The ac63255 Linux artifact supplies the baseline costs below; the newer corrected baseline is still running and must remain unchanged. Every proposed stage needs actual compiled measurements, complete fee-inclusive accounting and the existing gates.

## Current call path and what a split must preserve

`margin-controller/src/perps.rs:224` loads the pending open, validates the adapter/pool, withdraws margin receipt tokens, borrows, calls the facade and assigns resulting shares to the borrower before storing `PendingPerpsOpenExecution`. `cl-share-pool-facade/src/lib.rs:101` receives exact input, calls the vault, transfers newly minted shares to V3 and restores pre-existing dust balances. The vault `deposit` at `contract.rs:1637` currently claims rewards, collects actual swap fees, samples NAV/supply, transfers funds, converts part to the paired asset, adds liquidity, computes net NAV added and mints. Share transfer then actually claims rewards again; V3 custody assignment actually claims a third time. Activation subsequently transfers shares into receipt custody and performs debt/health/reserve finalization.

The existing facade is **not a registered custodian**. Its temporary share ownership is safe only within the current atomic invocation. An asynchronous mint-to-facade followed later by transfer would make the facade the reward beneficiary across ledgers. A split cannot silently retain that behavior.

## Measured components, not projected transaction totals

Peak Linux swap-open total: 235,455,777 CPU / 24,514,601 modeled memory bytes. Its vault deposit subtree: 166,503,487 CPU. Each row below is an inclusive subtree; memory counters reflect this invocation's metering and cannot be summed into a new transaction's peak or used as definitive cold-stage memory.

| Component | CPU | Modeled memory bytes |
| --- | ---: | ---: |
| First Aquarius actual reward claim | 6,598,979 | 2,754,147 |
| claim_all_position_fees | 53,570,569 | 2,885,131 |
| estimate_swap | 8,808,917 | 500,540 |
| swap | 10,955,817 | 1,081,892 |
| estimate_deposit_position | 4,543,019 | 554,737 |
| deposit_position | 64,865,976 | 4,744,847 |
| Share transfer, including actual claim | 10,301,800 | Separate full-stage measurement required |
| Actual claim inside that transfer | 5,973,639 | 1,727,679 |
| Custody assignment, including actual claim | 9,981,086 | Separate full-stage measurement required |
| Actual claim inside custody assignment | 5,968,733 | 1,380,573 |

Separating only the outer V3 wrapper leaves standalone deposit at 166.9M, so that is insufficient. Subtracting fee collection and conversion from the current vault deposit leaves approximately 93.17M CPU. This is a **partitioning estimate only**, not a stage benchmark: new entrypoint initialization, escrow reads/writes, authorization, cold accesses, freshness checks and history records add costs. Retaining transfer+assignment with that final mint would raise the estimate above 113M before remaining V3 work. These estimates justify trying a split, not predicting PASS.

## Smallest useful experiment and candidate that might fit

First measure a two-phase vault purchase with per-job escrow, keeping the current transaction policy:

1. **Prepare entrant funds and fees.** Convert only the new entrant's escrowed underlying into the paired asset, using current pool/oracle limits and a user-authorized minimum. Then collect existing-position fees, because the preparation swap itself generates fees belonging to the existing LP owners. Store the exact escrow amounts, beneficiary, job ID, deadline, versions and authenticated fee/position state evidence. Conversion estimate+swap+fee collection total about 73.34M before new wrapper/check costs, so combining them is worth measuring before introducing another stage. Keep escrow balances outside existing share NAV; a separate escrow contract gives the simplest auditable physical separation.
2. **Finalize the investment.** Validate the job and deadline, use fresh oracle/range checks, fresh total supply and fresh fee-inclusive NAV excluding escrow, actually claim rewards at the mint boundary, move the exact escrow balances into the pool position, value the actual net assets added and mint against that net value. Enforce the original min-shares/recipient and mark the investment consumed atomically. Existing owners must not bear entrant conversion/deployment costs. The prepared NAV is never reused as a price.

The safe *minimal-semantics* experiment retains mint, transfer and custody assignment atomically in phase 2. It likely remains over 100M; publish the measured failure honestly. A more ambitious candidate can move delivery to phase 3 only by adding explicit borrower-owned escrow-share semantics at mint:

3. **Deliver/assign committed shares.** The escrow holds a job-specific, non-fungibly-accounted slice of the fungible shares; the borrower is already its beneficial reward owner. Execute the original claim-first share transfer and original claim-first V3 custody assignment, with actual nested authorization and delta checks. Record V3 execution only after the full delivery succeeds. No shared-facade entitlement may accrue to the wrong user during the interval.

Implementing beneficiary-at-mint likely requires a new mint-to-registered-custodian operation and an additional actual assignment claim, or an equally explicit on-chain beneficial-ownership record integrated into the existing historical reward ledger. That extra work must be measured; no promise is made that phase 2 stays below 100M. An unregistered per-job contract by itself is insufficient unless its accrued reward entitlement is enforceably and historically tied to the borrower, including exited/failed jobs. It cannot require later discretionary governance to recognize normal ownership.

For V3, use a separate **fund/escrow** transition if adding its margin withdrawal/borrow cost to preparation exceeds the limit. Keep the existing begin and activation roles. The prototype may need begin → fund → prepare → invest → deliver → activate; this is a candidate state machine, not an assertion that this many stages are necessary or a production recommendation. Combine adjacent stages only after measured limits and intermediate-state proofs permit it. Do not split atomic funded debt repayment and permitted collateral seizure.

## Fee-inclusive valuation is the main dependency

A fee checkpoint from an earlier transaction is insufficient by itself: outside traders can move price/ticks and accrue fees before finalization. Comparing `get_slot0` alone is not enough; price can return to the same value while fee growth increases. The current pinned ABI exposes `get_all_position_fees(owner)` and position fee-growth data, but their exact relationship to the later actual paid amounts must be proved on the actual bytecode over rounding, ranges, liquidity changes and mutations.

Two possible mechanisms must remain explicit alternatives:

- **Strict freshness/retry prototype:** after preparation's actual fee collection, capture complete relevant pinned-pool fee-growth/position evidence; at finalization require evidence establishing no new uncollected fees. Also reject incompatible vault/pool configuration or position mutations. Fresh supply and NAV are still recomputed. If evidence is incomplete or fees have accrued, finalization rejects without minting and the job can reprepare. Merely checking a zero rounded pending-fee value does not prove that sub-unit fee-growth ownership can be ignored. This mechanism can establish safety in controlled unchanged-state cases, but outside trading may repeatedly invalidate it. That is an explicit liveness limitation, not a deployable solution by assumption.
- **Verified fee-inclusive final valuation:** prove the fresh view includes all accrued fees and reproduces actual payout/rounding sufficiently to allocate them exactly to existing owners, then use it at the final boundary with exact reconciliation. This would be a substantive fee-accounting design requiring validation against shared 00, which currently requires actual fees collected into NAV before mint/burn. Do not treat a convenient estimate or prototype success as permission to change that policy. If actual collection is still required in the final transaction, its 53.6M cost remains and this split may not satisfy 100M without a new venue operation.

A complete unchanged-fee witness may not be available through the current public ABI. Identify that as an implementation dependency, not an invented getter. Any new combined venue ABI or selective fee-accounting primitive requires a new reviewed bytecode pin and fresh evidence.

Do **not** hold a global ownership/withdrawal lock across transactions. It would block forced exits. Use per-job escrow, permit forced recovery at all times, invalidate/reprepare jobs after conflicting state changes, and never prune historical entitlements. Normal interposed ownership changes must either be supported by fresh supply/NAV accounting or cause a safe retry; no stale snapshot can price later entrants.

## Required intermediate states

Each transition is idempotent by job ID and exact stage; repeated execution rejects or returns the stored result without repeating transfers. Parameters bind owner, original caller, pool, vault/controller versions, both token identities, amount caps, minima, debt position, deadlines and permitted recipients. Expiry never grants a caller arbitrary collateral or waives rewards.

| State | Assets/custody | Debt | Allowed completion/recovery |
| --- | --- | --- | --- |
| Begun | Existing receipt/margin collateral remains in the current pending state | No new funded borrow yet | Current authorized cancel/expiry before funding |
| Funded escrow | Exact underlying held in controller-controlled job escrow; old shares untouched | Actual position-specific borrow recorded; interest can accrue | Proceed before deadline; otherwise repay from unconverted escrow plus externally funded shortfall. Release only after debt is fully repaid, or use valued funded seizure atomically |
| Prepared | Exact underlying/paired escrow inventory belongs economically to borrower; no new LP shares | Debt persists and accrues | Retry fresh fee preparation; cancel into funded repayment/recovery. Conversion loss is borrower-owned. Existing LP fees already collected stay with historical eligible owners |
| Invested | Newly minted shares locked in registered escrow with borrower beneficial ownership recorded at mint | Debt persists | Deliver exact shares or use funded debt repayment plus permitted share seizure; full repayment releases to owner. Claims/pending-view outage uses entitlement ledger and quarantine, never waiver |
| Delivered, not active | Shares in V3 custody, exact borrower allocation and pending execution recorded | Debt persists | Existing authorized activation with fresh health/reserve checks; on failure/expiry use authorized funded pending recovery or full repayment/release. No blind cancellation pretending no borrow occurred |
| Active | Receipt custody and position records finalized | Live position debt | Current close or full-repayment/release. Pending cancellation rejects without changing collateral, debt or rewards |

An expired job can be marked terminal/blocked from further investment permissionlessly, but debt and asset custody persist until the authorized repayment/seizure route settles them. A grace deadline and minimum funding/valuation rules must be explicit. Borrowing pauses and reserve shortfalls prohibit new risk while funded recovery/full repayment remain available. If both reward calls fail, rewards stay attached to their historical beneficiary independently of successful principal recovery.

Atomic components that must never cross a transaction boundary: exact asset receipt plus stage ownership record; final claim/fee validation/net-value pricing/mint; each claim-first beneficial ownership transition; funded debt repayment plus the precisely permitted collateral seizure; activation receipt custody plus debt/health/reserve finalization; terminal release only after verified zero debt. Individual stages revert entirely on insufficient funding, stale valuation, recipient/amount/auth mismatch, transfer failure or duplicate execution.

## Deposit, redemption and swap-close

**Direct deposit:** the same two-phase escrow purchase is relevant even at 1x. Current direct deposit CPU166,914,792 includes fees52,970,285, conversion estimate8,743,483 + swap10,820,323 and deposit64,651,134. A direct user's final mint can go to the user atomically, avoiding the asynchronous facade ownership problem, but fee freshness/entry-cost/NAV guarantees remain. No new entrant earns LP rewards before actual liquidity/share ownership begins.

**Direct redeem:** current total139,752,097 consists of fees52,903,433, withdraw62,219,427, actual claim4,825,964 and conversion estimate4,857,843 + swap6,816,945 plus wrapper work. Fees and withdrawal in distinct transactions are potentially feasible, but the current pool pays all position fees on a partial withdrawal. A stale pre-withdraw idle snapshot must not grant all newly accrued fees to the exiting fraction. First isolate the exact exiting LP/idle fraction with a claim-first burn/escrow ticket and fee-inclusive ownership allocation; then convert only that ticket's paired inventory for payout. Alternatively preserve shares until a later atomic burn but enforce their collateral lock and continued reward ownership. The ticket must own exactly the right post-burn claims; cancellation cannot remint stale-price shares or quietly socialize swap loss. If exact fee allocation still requires collection and withdrawal together, that pair alone exceeds100M and needs a stronger venue/accounting change. Full exit and partial exit must be distinguished in proofs.

**Swap-close:** current total184,218,309 includes share-transfer claim5,126,975, redeem138,601,791 (fees53,109,544; withdrawal60,562,999; redeem claim4,916,474; swap7,265,933) and V3/facade work. Reuse an explicit borrower-owned redemption escrow whose proceeds stay collateral for the live debt. Separate conversion after the LP/principal fraction is irrevocably assigned to the exit ticket. Close completion must still atomically repay debt and release only permitted surplus; a failed conversion leaves collateral in kind and supports funded recovery/full repayment. A token conversion stage must not pay the borrower before the debt is settled. Current recovery paths must stay available under claim outages and expiry.

## Prototype acceptance evidence

Use actual compiled forked contracts and pinned Aquarius bytecode, explicit real contract authorization, narrowly scoped test external auth, original policy and captured diagnostic profiles. Record each stage's complete CPU/memory, SDK entry total, unique transaction footprint, read/write bytes, events, unsigned envelope/auth bytes, fees and restoration costs; new stages can add cumulative cost/rent even if each fits. Signed cost/live-state remain separate unmeasured gates.

Interleave pool trades, range crossings, ownership changes, emissions, claims failing and pending-view failing between stages. Include before/after history, exited holders and repeated reconciliation; partial-exit fees; wrong job/caller/amount/recipient/controller; duplicate stage/replay; deadlines; insufficient liquidator funding; failed collateral transfer; activation reserve/health failure; archive/restoration; and rollback assertions. Preserve all three original claim-first boundaries and measure any additional escrow boundary. A controlled quiescent-pool PASS with incomplete fee witness or beneficial ownership is a failed architectural proof, not an approved stage change.

## Funding/delivery partition measurements

The same peak swap-open tree records `begin_margin_withdraw` at3,497,714CPU/34 incremental SDK entries; receipt `withdraw`16,949,918CPU/18; `borrow_for_margin_to_controller`12,639,123CPU/9. Their sum is33,086,755CPU/61 entry deltas, before V3 root/config/pool/authentication and new job escrow work. This suggests funding CPU room but a potentially tight100-entry gate. New reserve enforcement also needs measurement. The adapter binding check adds680,799CPU/6 entries in this trace.

Share delivery `transfer`10,301,800CPU/8 entry deltas and `custody_assign`9,981,086CPU/15 sum20,282,886CPU/23 **incremental warm** entries. These are not standalone footprint forecasts: those operations reuse vault/Aquarius/configuration state already touched by the current deposit. A new delivery transaction will touch those keys cold, add job/V3 state and real authorization overhead. It must run under the original SDK100-entry gate and separately count unique transaction LedgerKeys. No current evidence proves delivery itself must exceed100 entries.
