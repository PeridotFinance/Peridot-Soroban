# Independent isolated split-prototype review

Status: implementation review in progress, 2026-11-02. This document is separate
from the unchanged production source and the running corrected baseline. It is
not a resource pass, completed lifecycle proof, or deployment recommendation.

## Review scope

Review cloned vault/V3/escrow under `target/cl-split-workspace`, with test harness
owned by the lead. No production source, baseline proof source, limits, shared
00, borrowing configuration or authorization guard is edited by this reviewer.
The full accounting analysis is `target/cl-split-design/accounting-review.md`.

## Agreed design checks

The vault owner proposes `split_prepare(escrow,job,deadline) -> BytesN<32>` and
`split_deposit_pair(escrow,owner,job,amount_u,amount_o,min_shares,fence) -> i128`.
Preparation performs actual fee collection, then persists an immutable-deadline,
per-job state witness. Finalization compares the witness, proves zero current
integer fees, refreshes composition/NAV/supply, claims before mint, deposits the
exact escrow assets, mints to registered escrow, and performs a real
`custody_assign` claim before the transaction ends. Delivery later retains the
original transfer and controller-assignment claims. The additional mint-time
assignment is a real extra claim to measure, not a replacement for an existing
claim-first boundary.

Required witness inputs are configuration, parameters, pool executable identity,
both global fee-growth accumulators, slot0, both configured boundary ticks, full
position fee checkpoints/tokens owed, active liquidity, and owner position
snapshot/range set. Reject extra unaccounted ranges, malformed/failed views,
expired/mismatched intents and consumed jobs. Re-preparation may refresh the
witness only with the original deadline. A new deadline requires a new
authorized intent, never silent expiry extension.

These inputs form a conservative concurrency fence, not proof of venue arithmetic.
Test that omitted repeated zero collection cannot change fractional carry or
future payouts. Compare against the ordinary collection path at the same
pre-state and through subsequent swaps/claims. Exact position/global-growth
equality is stronger than an integer zero-fee reading, but any rounding side
effect of the omitted collection remains a proof obligation.

## Mandatory invariants to inspect in source

- Pre-mint escrow assets and donated dust are excluded from shared-vault NAV and
  reward weight. Each intent accounts for its own exact assets; cancellation does
  not sweep another intent or donations.
- Final NAV and supply are current, include all incumbent idle principal and
  collected fees, and exclude quarantined reward tokens. Do not reuse a stored
  price/supply from preparation.
- The new shares have the original owner's effective reward weight before the
  mint transaction commits. `custody::received` accounts for the physical mint,
  and `custody_assign` removes exactly its unassigned amount. No multi-ledger
  facade ownership or accidental unassigned-custody interval is allowed.
- During delivery, physical transfer and assignment into controller custody are
  atomic. Missing claim/view evidence does not justify quietly losing historical
  rewards; recovery uses established forced hooks without a voluntary waiver.
- Public job operations require their actual actor/controller authorization with
  exact amounts/recipient/nonce. Contract authorization stays real. No synthetic
  administrator identity is portrayed as account-signature proof.
- Every job ends once. Preconditions, deadline, retry, pre-mint cancellation,
  post-mint release, and debt states are explicit. Minted shares cannot be
  cancelled for a promised original underlying amount.
- If debt exists, full repayment and permitted release/seizure are atomic. Paused
  borrowing, reserve shortfall, absent keeper, and missing attribution evidence
  do not add new permissions blocking recovery.
- No vault-wide ownership lock prevents unrelated transfer, emergency exit,
  repayment/release or funded liquidation. Those actions may invalidate a job's
  witness, requiring re-preparation; they must not be stopped for that job.

## Lead-harness adversarial checklist

| Scenario | Required assertion |
| --- | --- |
| Prepare → external pool swap → finalize | Fence failure; exact escrow and entitlement state unchanged; retry or in-kind cancel remains possible. |
| Fractional fees with integer fee view zero | Ordinary recollect and fenced candidate agree through future payouts/rounding, or candidate fails closed as unproved. |
| Emissions change between each stage | Actual claims execute at each boundary; original beneficiary receives minted-share rewards across delayed delivery. |
| Holder transfer, partial/full exit, newcomer between stages | Fresh valuation/supply or explicit invalidation; no historical newcomer windfall; forced exits remain available. |
| Mint → delay → claim/view outage → recovery | Escrow beneficiary retained; authorized share release preserves booked/unresolved reward history without waiver. |
| Token/share donation to escrow or controller | Job cannot appropriate dust; no assignment of donated unowned shares to job owner. |
| Failed second token transfer / LP deposit / post-mint claim | Complete invocation rollback, no partial share creation or consumed job. |
| Missing nested auth / changed owner, recipient or amount | Actual scoped authorization rejection at the intended call, not setup/resource panic. |
| Duplicate finalize, delivery, cancel or recovery | Reject/no second payout; settlement and custody replay markers remain intact. |
| Expired/archived intent, position and reward history | Measured restoration; exact prior ownership retained, no default-zero recreation. |
| Borrow pause/reserve change after draw, if a debt-bearing prototype exists | Final origination checks reject as appropriate; funded debt repayment plus release remains possible and atomic. |

## Resource conclusions permitted by evidence

Each public stage needs its own unchanged internal-policy acceptance report and
captured-network diagnostic, plus unsigned target-runtime transaction evidence.
Include new state reads, fresh views, extra claim, auth, return/events and restored
keys. Record SDK entry totals and unique transaction footprint separately.

The old aggregate swap-open failure does not establish that any new individual
operation fails. Conversely, a subtraction or bounded subtree estimate does not
prove a new stage fits. Identify an indivisible over-limit operation only after
that candidate operation is actually executed/measured. Signed costs and live
state remain separate missing gates.

## First cloned-vault source pass

Reviewed the landed `split_prepare`, `split_state_fence`, `split_fresh_root`, and
`split_deposit_pair` implementation in cloned `cl-share-vault/src/contract.rs`.
The implementation rejects extra/wrong owned ranges, mismatched position versus
vault liquidity, nonzero/malformed fee views, nonzero owed token amounts, changed
hashed witness, expired/consumed jobs, and custodians as beneficiaries. The fence
includes both global growth values, boundary tick records, slot0, active liquidity,
full position and owner snapshot, pool code and vault configuration/parameters.

Finalization refreshes composition and oracle root, reads current supply and NAV,
checks exact asset balance deltas, offers only the specified pair, requires actual
LP minting, and prices the net addition. `mint_shares` calls `custody::received`;
the subsequent actual `custody::assign` claims and establishes the owner's weight
before returning. Both used-job marker and mint/assignment are atomic. No global
ownership lock was introduced. Owner/amount/minimum binding relies on the
registered escrow's lifecycle, which still requires separate source review.

The final method retains an `estimate_swap` oracle-band check. That is a real
necessary measured cost, even though the conversion swap moved to another stage.
The earlier subtractive estimate cannot assume that quote cost disappeared.
The extra custody-assignment claim and complete witness reads also need actual
measurement. No resource conclusion is made from this source pass.

The fractional-carry/repeated-zero-collection equivalence remains unproved until
the actual-bytecode differential test runs through later accrual and payouts.
No source issue was identified in this first vault-only pass; that is not an
approval of the escrow/V3 lifecycle or of the proposed omitted collection.

## Debt-bearing prototype entrypoint isolation

The implementation owner now proposes Long-only `split_fund`, `split_convert`,
`split_prepare`, `split_mint`, `split_deliver`, and `split_recover` on V3, with
configured escrow wiring. Funding withdraws the old margin receipt principal
and draws debt before canonical `PendingPerpsOpenExecution` exists. This new
state cannot be treated as an ordinary unswapped pending position.

Every Funded/Converted/Prepared/Minted intermediate state needs explicit rejection
from these legacy paths, with complete rollback:

| Existing path | Hazard without a split-state exclusion |
| --- | --- |
| `swap_open_position_v3` | A second margin receipt withdrawal and/or borrow against the same position. |
| `execute_open_position_v3`, `activate_open_position_v3`, expired `resolve_pending_open_v3` | Premature activation using no execution or a synthetic partial execution whose assets remain outside controller custody. |
| `cancel_pending_open_v3`, `expire_pending_open_v3` | Returning original margin pToken credit after those pTokens have already been withdrawn. Existing debt checks help but are not a substitute for exact custody/state checks. |
| Legacy pending `liquidate_position_v3` conversion | Treating escrow collateral as controller-held and entering a settlement route that does not control it. |
| Existing `recover_pending_open_funded` | Repaying debt then attempting to release nonexistent controller-held position assets, or clearing records while escrow remains live. |

An explicit active-split marker is preferable to making ordinary execution records
carry undocumented sentinel meanings. It must be cleared only when delivery
atomically installs the exact canonical execution amount and establishes
beneficial controller custody, or when full repayment plus escrow release and
position cleanup succeeds atomically. Repeated funding/delivery/recovery must
reject. Full repayment recovery includes the new pre-refund fee-entitlement
checkpoint and preserves other suppliers' historical fee ownership.

An absent owner before delivery is a genuine uncovered case if only owner-funded
`split_recover` exists. Existing funded liquidation cannot be claimed to cover
two escrow assets or shares outside its expected receipt custody. Preserve that
gap explicitly: deadlines alone do not authorize a third party to seize assets,
and permissionless cancellation cannot release principal with live debt. A
future funded third-party recovery requires current valuation, bounded seizure,
atomic debt payment, original-owner surplus, and all historical reward hooks.

## First escrow/V3 source pass

Read cloned `margin-controller/src/split_open.rs`, the new escrow `src/lib.rs`,
and the guards added to cloned `perps.rs` / `pending_recovery.rs`.

The split controller records its own phase and immutable escrow/owner/deadline;
the escrow maintains the matching per-position token/share accounting. Funding
requires current borrow eligibility, configured reserve policy and enabled cash
borrowing, exact receipt withdrawal/borrow deltas, an owner-authorized bound,
and a post-funding reserve assertion. Conversion uses an actual fresh guarded
quote plus the owner's minimum and exact asset deltas. Each job tracks exact
amounts rather than sweeping the escrow's whole balance, preserving unrelated
jobs and donated dust structurally.

Legacy swap/cancel/expire reject any split job. The common activation routine and
ordinary funded pending recovery reject phases before delivered. Execute,
expired resolve and legacy pending liquidation cannot proceed before delivery,
because no canonical execution exists; the common activation guard supplies a
second check. Delivery performs physical share transfer, controller beneficial
assignment, and creation of the canonical execution record in one transaction.
These guards address the identified unsafe-unswapped-state concern in source;
the adversarial harness must still exercise every phase.

Pre-delivery `split_recover` performs full post-accrual repayment, checks zero
debt, releases the exact escrow assets or shares to the recorded owner, settles
the owner's fee epoch before refunding reserved fee pTokens, and clears the
position. Share release prepares a forced custody transfer with no waiver.
This transaction does not consult current origination pause/reserve headroom or
the expired deadline. Phase-5 recovery delegates to the existing complete
pending-funded route. A failed later release therefore rolls back debt payment.
After completion, the retained terminal job marker prevents reuse; canonical
record cleanup prevents replay through older entrypoints.

One strengthening was requested from the escrow owner: mint currently asserts
aggregate `custody_allocation >= minted`. With multiple jobs for the same owner,
a prior allocation could satisfy that comparison. Record allocation before and
require the exact delta `after == before + minted`. The current cloned vault does
perform the correct assignment, so this is not an observed unauthorized release;
the stronger assertion makes the escrow's job invariant independently explicit.

No additional direct source-level escape was found in this bounded pass. The
owner-absent debt-bearing pre-delivery route remains intentionally unimplemented.
Fractional fee equivalence, actual authorization/rollback at every intermediate
phase, restoration, and individual resource feasibility remain required tests.
There are no prototype execution/resource results in this review yet, so it does
not identify an indivisible operation as exceeding or fitting 100M instructions.
