# Isolated cloned vault ABI

Only `target/cl-split-workspace/contracts/cl-share-vault/{src/contract.rs,src/pool.rs}` changed. Every new method rejects Mainnet. No original claim boundary or production source was changed. ABI methods are additional prototype entrypoints on `ClShareVault`:

```rust
split_assets() -> (Address, Address, Address, u32)
// pool, underlying, other, underlying_index
split_quote_convert(amount_u: u128) -> u128
// Minimum received paired amount under fresh oracle + current pool estimate,
// original divergence check and configured slippage. Quote and actual escrow
// swap MUST occur in the same transaction. Escrow also enforces user minimum.
split_fence() -> BytesN<32>
split_prepare(escrow: Address, job: u64, deadline: u64) -> BytesN<32>
split_deposit_pair(escrow: Address, owner: Address, job: u64,
    amount_u: u128, amount_o: u128, min_shares: u128, fence: BytesN<32>) -> i128
```

Prepare requires the registered escrow's actual authorization, an unused job and a future deadline at most24h away. A retry can refresh fee evidence but cannot extend the original deadline. It collects actual existing fees AFTER escrow conversion, refreshes composition and stores the fence. It creates no global ownership lock. The pending record has normal persistent TTL; consumed markers persist and must be restored rather than bypassed when archived.

The fence hashes exact XDR of vault Config/Params/RangeParams, pool code hash, pool fee/protocol-fee/tick-spacing/token identities, oracle symbol mappings, global fee growth for both tokens, both range TickInfo records, slot0, active liquidity, full PositionData and user position snapshot. Only zero or one configured range is accepted; cached/actual raw liquidity must agree. Integer fee views and tokens_owed must be zero, but the fee-growth fence additionally preserves fractional state rather than treating zero integer fees as sufficient evidence. Pool/vault pauses reject.

Finalization authenticates the same registered escrow, job, immutable deadline and exact fence. It rejects a custodian beneficiary. It then performs the actual mint-boundary claim, fresh independent oracle reads with no stale-cache fallback, fresh position composition, a fresh oracle-band check against the pool quote and fresh total supply/NAV. The caller authorizes these exact nested token transfers:

```text
underlying.transfer(escrow, vault, amount_u)
other.transfer(escrow, vault, amount_o)
```

They occur under `split_deposit_pair`; the escrow must provide the real contract authorization tree. Exact token balance deltas must match both requested amounts. Only these two entrant amounts are offered to `deposit_balances`; existing vault dust is not offered. That existing helper authorizes exact pool-quoted spends and reconciles actual/report deltas. Zero liquidity mint rejects; deployment cap is enforced conservatively. Net actual NAV added determines shares; `min_shares` must be positive and satisfied.

Mint goes to the registered escrow via the existing `mint_shares`, which records unassigned custody. The same transaction invokes the existing **normal custody assignment**, including its additional actual upstream reward claim, allocating all minted shares to `owner` and resetting debt. A persistent consumed marker is written and preparation removed only on successful completion. Original subsequent share-transfer and V3-assignment claims remain required. No unknown interval may be assigned through an off-chain assumption.

The escrow is the trusted lifecycle contract, so it must bind owner, amounts, minimum shares, debt position, recipients and immutable job to the original authorization. Vault-level job scoping cannot substitute for that escrow policy. Recovery must retain historical allocations and use custody recovery authorization where claims fail.

Measurement warning: finalization intentionally retains a fresh `estimate_swap` for the oracle band. It also adds fence reads, fresh oracle reads, an extra custody-assignment claim, exact entrant-transfer deltas and persistent job records. The earlier93.17M subtraction estimate is not the implemented stage's cost. Claim-first correctness and stale-state guards are retained even if the measured stage fails100M.

Outstanding accounting proof: compare skipped zero recollection against repeated ordinary zero fee collection using the actual pinned pool, then accrue/pay future fees across rounding and range paths. The full fee-growth fence establishes unchanged inputs between preparation and finalization; it does not by itself prove how a second zero collection versus deposit mutates fractional carry. Record a failure if that differential differs. New policy/stage adoption remains unauthorized.

Build-fixture correction: the initial77d6281e… WASM used `test-default-admin` without the harness's explicit synthetic admin binding and failed during initialization. It is not authorization-rejection evidence. Rebuilt without that feature, using `AQUARIUS_LP_VAULT_INIT_ADMIN=CAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD2KM` and `CARGO_TARGET_DIR=target/cl-split-cargo`. Current WASM SHA256 is `b549cb931966b57d00fa99be6105e908af6d172e2a98dccf850ab4b9adda28df`,93,878bytes. This C-address is a test-only fixture identity; it proves no real account signature behavior. Production identity constants remain unchanged. Both build logs remain in the cloned vault directory.
