# Isolated compiled split prototype — V3 custody/debt plan

This is an experiment design, not a production stage/policy change or Stage1 completion. Baseline source and evidence remain unchanged. Keep internal100M/100-entry/50-write limits and all three claim-first boundaries; retain borrowing-disabled deployment preparation, production maintenance margin unset, validation Mainnet rejection, no signing/broadcasting/secrets/Upshift. All new prototype artifacts must have separate names, source hashes and WASM hashes, and all compiled flows run both unchanged profiles plus check_budget.

## Findings and smallest candidate

Current `swap_open_position_v3_impl` withdraws reserved margin receipt shares, borrows debt into V3, invokes adapter/facade, and only then writes `PendingPerpsOpenExecution`. Facade performs the complete vault underlying deposit, transfers the resulting shares back to V3, and V3 assigns their beneficial owner. These are one atomic transaction. No successful existing intermediate state has borrowed debt but neither an execution record nor recoverable collateral.

Current vault deposit runs primary reward claim-first, collects LP swap fees, refreshes composition, samples full NAV, accepts input, balances the pair, deposits into Aquarius, samples postdeployment NAV, and mints net-added-value shares. Transfer and V3 custody assignment then run their own claim-first boundaries. Simply minting idle shares (`deposit(..., invest=false)`) and deploying later is not an equivalent split: later swap costs would be socialized across incumbent shares. Splitting after mint to the existing facade is also unsafe: the facade is currently a direct reward owner, not a registered beneficiary-aware custodian.

A no-debt `prepare_fees` followed by final same-transaction zero-fee view is the smallest correctness probe, but not a demonstrated internal-limit solution. Existing measured subtrees supplied by accounting review sum to roughly112.49M CPU even after moving fee collection, before wrappers. The more useful bounded prototype splits conversion into an explicit per-job escrow, then performs fee collection AFTER conversion and finally performs a balanced deposit plus mint/transfer/assignment atomically. Accounting review estimates a roughly92.72M lower bound for deposit+three claims+two valuation estimates before the fee fence and wrappers; this is not evidence of headroom. Measure before claiming feasibility.

Pinned Aquarius exposes `get_all_position_fees(owner)->Vec<u128>`, `get_user_position_snapshot(owner)`, `estimate_withdraw_position(...)`, `get_slot0()`, `claim_all_position_fees(owner)`. The fee view is distinct from AQUA pending-reward view. Its exact equivalence to claim, including fractional rounding and deposit interactions, is a proof dependency; there is no already-verified generic fee-growth epoch fence in the current client. A preparation timestamp or slot price is not sufficient evidence: out-and-back trades may accrue fees with the same price, and the deposit's own conversion swap accrues incumbent LP fees.

## Isolated implementation boundary and reuse

Use a separately named, Mainnet-rejected prototype controller/vault/escrow source tree and binaries. Do not patch the production controller, facade, vault, proof map or baseline harness while its run is active. The prototype must bind real compiled receipt markets and actual pinned Aquarius; synthetic oracle/state and external account authorization remain explicitly labelled.

Reuse or copy with explicit changes:

- `perps.rs::begin_open_position_v3_impl`: existing reservation of margin and fee, pinned markets/pool/config, minimum outputs, owner, expiry, margin-borrow-state initialization. Keep the cash-funded Long CL restriction initially; extending Short is a separate measured proof, not implicit support.
- `perps.rs::swap_open_position_v3_impl`, up through margin withdrawal and `borrow_for_margin_to_controller`: extract into `fund_open_escrow`. Replace the direct pool swap with exact transfer into a job-accounted escrow and write a funded phase in the SAME transaction. It must never return debt without that record and verified escrow balance.
- `validate_direct_pool`, `authorize_controller_subcall`, bounded input authorization and actual balance deltas: retain their checks for each conversion and deposit. Do not authorize the entire escrow wallet or trust quoted/reported spends alone.
- `activate_open_position_v3_from_execution`: reuse only after the final atomic mint/transfer/beneficiary-assignment records `PendingPerpsOpenExecution` with measured actual shares held by V3. This keeps receipt deposit, fresh health, fee collection and final borrowing/reserve enforcement after all open costs.
- `cancel_pending_open_v3_impl`, `expire_pending_open_v3_impl`, `release_unswapped_pending_open`: valid ONLY for Reserved with zero debt and no escrow assets. Add explicit rejection for every funded prototype phase. Existing execution absence alone no longer identifies an unswapped safe cancellation.
- `recover_pending_open_funded_impl`: existing implementation assumes shares already at V3 and an execution marker. Add a separate escrow-state branch, not a fabricated execution record. Full current debt repayment precedes exact escrow asset release; both are atomic. Keep the newly fixed `accrue_user_fee` before reserved-fee refund.
- Existing `repay_margin_position_v3`/`release_debt_free_position_v3` remain for Open/Closing. They cannot recover the new pre-share phases without an explicitly implemented branch.
- Existing `execute_open_position_v3` is a post-swap finalizer, not a pre-swap stage. Never apply the outdated begin/execute/swap/activate ordering.

## Proposed prototype methods and job fields

Method names below are proposed NEW prototype ABI, not claims that production entrypoints exist:

`fund_open_escrow(owner,id,expected_job_nonce,max_borrow,max_input)`;
`convert_open_escrow(owner,id,nonce,max_in,min_out)`;
`checkpoint_open_fees(owner,id,nonce)`;
`mint_open_shares(owner,id,nonce,min_shares)`;
`recover_escrow_funded(owner,id,nonce,max_repay,min_return_0,min_return_1)`;
`liquidate_escrow_funded(liquidator,id,nonce,max_repay,min_seize_0,min_seize_1)`;
`renew_open_intent(owner,id,nonce,new_deadline,new_minima)`.

A stable registered WASM escrow avoids registering a new custodian for every job, but MUST account per `(controller,position_id,job_nonce)` and use exact assigned deltas. No escrow-wide pool donation balance is spendable for a job. Its public methods accept only the bound controller's actual nested authorization; it has no admin sweep/transfer of active job assets. One job must not block another owner's exit or any direct vault holder.

Persist a versioned job: phase; owner/beneficiary; controller/escrow; position id/nonce; immutable margin/debt/position vaults; underlying/paired/share addresses and pool/binding/range/config generation; reserved margin/fee pTokens; actual withdrawn margin; principal borrowed; escrow token0/token1 assigned amounts; actual share output (only after mint); max approved input/borrow; conversion output floors and min shares; original deadline and approved renewal nonce; fee-checkpoint generation/composition observation; completed operation markers. Store bounded active-job counts and a terminal replay marker. No unbounded holder enumeration. Do not store a stale debt balance as authoritative: ask the receipt and accrue interest at recovery/finalization.

Every phase updates state AFTER verified deltas within the same successful transaction. Repeated transition calls reject without transfers/debt changes; either return an explicit immutable receipt or reject, never rerun. State/TTL restoration must preserve all job fields and receipt borrow state; archive expiry never cancels debt or makes assets unowned. Terminal job cleanup cannot prune the separate vault historical reward entitlements.

## State and custody/debt/recovery table

| Phase | Custody and entitlement | Debt and transitions | Cancellation/recovery |
|---|---|---|---|
| Reserved | V3 holds reserved margin receipt shares and reserved open-fee shares; no new CL shares/rewards | No borrowed debt. Fund only before deadline with owner exact authority, cash borrowing enabled, supported markets, reserve check, bounds and pinned route | Existing authorized cancel or permissionless expiry returns margin+fee to free margin after fee checkpoint. No venue/reward call required |
| CashEscrowed | Stable escrow holds exactly job-assigned underlying cash; owner is economic beneficiary; no new CL rewards exist | Funding transaction atomically withdraws margin, creates receipt debt and transfers cash into escrow. Interest starts now and continues through delays/outages. Conversion needs owner, nonce, live deadline/approved bounds | Never zero-debt cancel. Owner may externally fund complete post-accrual repayment and atomically receive escrow cash; insufficient payment/transfer failure rolls back all. Borrow pause/reserve shortage cannot block repayment/release |
| BalancedEscrowed | Escrow owns exact per-job token0/token1 amounts after verified Aquarius conversion; still no new CL shares/rewards | Conversion spends only job input, actual output reconciled. No automatic retry with larger limits. Existing vault LP earns conversion-swap fees | Same funded recovery, returning both legs without a venue swap or governance attribution. Optional fresh healthy continuation; unhealthy funded liquidation requires new explicit two-leg valuation branch |
| FeesCheckpointed | Same escrow legs; old vault holders own collected LP fees as idle vault assets. No global holder lock | Fee checkpoint occurs after conversion. It is an observation, not irrevocable authorization to mint. Final transaction must prove exact fee eligibility/fresh composition or reject | Fee-prep failure leaves job/escrow unchanged. Pool trading/other holder activity may invalidate observation; retry checkpoint, or owner funded recovery. No automatic loss of escrow |
| SharesAssigned | In ONE transaction balanced LP deposit, share mint with beneficiary-at-mint, share transfer to V3 and V3 beneficiary assignment succeed; actual shares/execution marker stored | No committed state between physical mint and final beneficiary assignment. Existing debt continues. Receipt activation is still separate and runs all current health/cost/reserve checks | Existing funded pending-share recovery applies, preserving accrued/quarantined rewards. Failed activation rolls back activation only and leaves this phase recoverable |
| Open / Closing | Existing receipt/margin custody and reward beneficiary ledger | Existing current health, interest, reserve-complete-open semantics | Existing close or full repayment/release; funded repayment+permitted seizure stays atomic, never voluntary waiver on forced exit |
| Terminal | Asset allocation zero, debt zero or liquidation fully settled; replay marker retained | All further transition attempts reject | Reward claims/attribution for historical/exited beneficiary remain in vault ledger and independent of job deletion |

A deadline is NOT authority to seize, waive or forgive debt. Risk-increasing fund/convert/mint operations reject after the explicit phase deadline. An owner-signed renewal may update only deadline/minimums under a new nonce and fresh checks; it cannot change owner, beneficiary, debt market, tokens or existing custody. After expiry, funded recovery remains available; a fresh unhealthy position may use permitted funded liquidation. Permissionless expiry may mark the job overdue but cannot transfer debt-backed assets. Healthy pending collateral cannot be liquidated simply because time expired.

## Three claim-first boundaries and balanced-mint dependency

1. Vault must claim/checkpoint incumbent and beneficiary rewards BEFORE introducing minted share weight. A new `deposit_balanced_for` must bind escrow job beneficiary and exact legs, price incumbents from fresh fee-inclusive NAV, and charge only the entrant's measured conversion/deposit costs. Incoming escrow legs must be excluded from incumbent NAV until the before snapshot; this is why holding them in a separate escrow is preferable to mixing them into vault idle balances.
2. Physical share transfer escrow→V3 must use a beneficiary-bound custody transfer context, run the current claim-first ownership boundary and exact real contract authorization.
3. V3 custody assignment runs the current claim-first owner boundary before its beneficiary allocation changes. All three execute and are measured. Do not claim that an earlier fee/reward checkpoint substitutes for any one of them.

Beneficiary-at-mint needs a new explicit vault/custody path. Current `mint_shares` plus registered-custodian `received` would mark supply unassigned; calling the ordinary assignment adds a fourth reward call. Either retain and meter that extra call, or design one atomic mint-and-assignment boundary that performs the same claim-first once before BOTH weight changes. No unassigned/direct-facade ownership may persist between transactions, and no synthetic bookkeeping assignment without the existing checks is acceptable. The accounting reviewer must approve this dependency before implementation claims.

## Fee/NAV fence and failure behavior

The final balanced deposit must read actual fee entitlement and position composition at its ownership boundary. Two possible bounded strategies require differential proof:

- Strict zero-fee fence: prepare claims all LP fees after conversion; final transaction reads `get_all_position_fees` and requires the exact two-token zero vector, fresh principal composition and independent oracle NAV. Any intervening accrued fees/view failure rejects before moving escrow funds. Same-price/out-and-back swaps must invalidate if they generated fees. Rounded-zero versus fractional fees and deposit-triggered fee settlements must be checked against actual Aquarius; unsupported evidence means this path remains disabled.
- Fee-inclusive final valuation: include exact verified owed-fee amounts in incumbent NAV, and reconcile all implicit fee payments/rounding during deposit. This can tolerate intervening trades but requires exact venue behavior and avoids double-counting collected idle fees. Do not infer pending fees from a later cumulative reading or use lower-bound lending NAV for mint pricing.

Any fee/reward/view/pool-deposit failure leaves the job in its prior phase with all assets and debt preserved. Vault ordinary holder transfers/exits remain available; no global ownership lock is introduced. An unrelated exit may change NAV/supply; final mint must reprice fresh or reject/reprepare, never apply a stale denominator. Primary claim failures still stop ordinary mint/transfer/assignment; recovery uses current quarantine/entitlement preservation and never treats forced exit as waiver.

## Atomic funded liquidation of new escrow states

Existing receipt repayment is usable, but existing share/receipt seizure math is NOT automatically applicable to cash/two-leg escrow. A new isolated path must obtain fresh conservative token valuations, determine permitted liquidation eligibility and capped seizure, require the liquidator's full post-interest debt payment, then release only permitted job assets and return surplus to the owner in the SAME transaction. Insufficient funding, bad valuation, unexpected token deltas, failed seizure/surplus transfer, or nonce mismatch rolls back debt repayment and every asset movement. Neither repayment nor seizure is its own transaction stage. If pricing is unavailable, third-party seizure fails closed; owner-funded full repayment and in-kind return remains the non-governance recovery route.

Borrowing pause blocks new debt and activation under current reserve policy, but cannot block funded recovery/full repayment. Reserve shortfall after funding/while delayed may reject activation; it never grants an unrestricted collateral escape or disables the atomic repayment route. New prototype state handling is mandatory before enabling its funded phase: exposing fund first and postponing recovery implementation is unsafe.

## Required evidence before any feasibility conclusion

Compile all real contracts with Stellar CLI; actual pinned Aquarius; exact nested auth, no blanket mocks. Measure every transition as its own full invocation AND unsigned transaction; separately sum the full user journey with all fee/rent/restoration components. Compare both fixed profiles, SDK entry totals and unique footprint keys. Include nonce/replay/wrongowner/missingnested auth/wrongamount/wrongrecipient; debtinterest across delayed phases; pool price/range/intervening holder ownership changes; conversion-generated fees; fee-view/claim rounding and partial exits; outages of both reward/view calls; pause/reserve changes at every phase; expired/renewed/archived jobs; asset donation isolation; failed final transfer rollback; actual post-cost finalization failure; and complete owner-funded / liquidator-funded recovery from EVERY funded phase. Do not report stage CPU below100M while omitting wrapper, claim, authorization or restoration costs.

Until those paths and fee/beneficiary dependencies are compiled and proven, this is an isolated architecture experiment only. Its absence of production borrowing enablement is unchanged.
