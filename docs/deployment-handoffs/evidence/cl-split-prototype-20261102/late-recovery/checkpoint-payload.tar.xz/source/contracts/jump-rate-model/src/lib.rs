#![no_std]
use soroban_sdk::{
    contract, contractevent, contractimpl, contracttype, Address, BytesN, Env, String,
};

const SCALE_1E6: u128 = 1_000_000u128;
pub const DEFAULT_INIT_ADMIN: &str = "GATFXAP3AVUYRJJCXZ65EPVJEWRW6QYE3WOAFEXAIASFGZV7V7HMABPJ";
const TTL_THRESHOLD: u32 = 500_000;
const TTL_EXTEND_TO: u32 = 1_000_000;
const UPGRADE_TIMELOCK_SECS: u64 = 24 * 60 * 60;

#[contracttype]
pub enum DataKey {
    BaseRatePerYear,       // u128 scaled 1e6
    MultiplierPerYear,     // u128 scaled 1e6
    JumpMultiplierPerYear, // u128 scaled 1e6
    Kink,                  // u128 scaled 1e6
    Admin,                 // Address
    PendingUpgradeHash,    // BytesN<32>
    PendingUpgradeEta,     // u64 unix timestamp
}

#[contract]
pub struct JumpRateModel;

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ModelInitialized {
    pub base_rate: u128,
    pub multiplier: u128,
    pub jump_multiplier: u128,
    pub kink: u128,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ModelParamsUpdated {
    pub base_rate: u128,
    pub multiplier: u128,
    pub jump_multiplier: u128,
    pub kink: u128,
}

#[contractimpl]
impl JumpRateModel {
    pub fn initialize(
        env: Env,
        base: u128,
        multiplier: u128,
        jump: u128,
        kink: u128,
        admin: Address,
    ) {
        admin.require_auth();
        if env
            .storage()
            .persistent()
            .get::<_, Address>(&DataKey::Admin)
            .is_some()
        {
            panic!("already initialized");
        }
        assert_expected_admin(&env, &admin);
        if kink > SCALE_1E6 {
            panic!("invalid kink");
        }
        if base > 10_000_000u128 || multiplier > 10_000_000u128 || jump > 10_000_000u128 {
            panic!("invalid rate params");
        }
        env.storage().persistent().set(&DataKey::Admin, &admin);
        env.storage()
            .persistent()
            .set(&DataKey::BaseRatePerYear, &base);
        env.storage()
            .persistent()
            .set(&DataKey::MultiplierPerYear, &multiplier);
        env.storage()
            .persistent()
            .set(&DataKey::JumpMultiplierPerYear, &jump);
        env.storage().persistent().set(&DataKey::Kink, &kink);
        bump_ttl(&env);
        ModelInitialized {
            base_rate: base,
            multiplier,
            jump_multiplier: jump,
            kink,
        }
        .publish(&env);
    }

    pub fn get_borrow_rate(env: Env, cash: u128, borrows: u128, reserves: u128) -> u128 {
        ensure_initialized(&env);
        bump_ttl(&env);
        let util = Self::utilization(cash, borrows, reserves);
        let base: u128 = env
            .storage()
            .persistent()
            .get(&DataKey::BaseRatePerYear)
            .expect("base rate missing");
        let mult: u128 = env
            .storage()
            .persistent()
            .get(&DataKey::MultiplierPerYear)
            .expect("multiplier missing");
        let jump: u128 = env
            .storage()
            .persistent()
            .get(&DataKey::JumpMultiplierPerYear)
            .expect("jump missing");
        let kink: u128 = env
            .storage()
            .persistent()
            .get(&DataKey::Kink)
            .expect("kink missing");
        if util <= kink {
            base.saturating_add(util.saturating_mul(mult) / SCALE_1E6)
        } else {
            let normal = base.saturating_add(kink.saturating_mul(mult) / SCALE_1E6);
            let excess = util - kink;
            normal.saturating_add(excess.saturating_mul(jump) / SCALE_1E6)
        }
    }

    pub fn get_supply_rate(
        env: Env,
        cash: u128,
        borrows: u128,
        reserves: u128,
        reserve_factor: u128,
    ) -> u128 {
        ensure_initialized(&env);
        bump_ttl(&env);
        if reserve_factor > SCALE_1E6 {
            panic!("invalid reserve_factor");
        }
        let one_minus_rf = SCALE_1E6.saturating_sub(reserve_factor);
        let borrow_rate = Self::get_borrow_rate(env.clone(), cash, borrows, reserves);
        let rate_to_pool = borrow_rate.saturating_mul(one_minus_rf) / SCALE_1E6;
        let util = Self::utilization(cash, borrows, reserves);
        util.saturating_mul(rate_to_pool) / SCALE_1E6
    }

    pub fn set_params(
        env: Env,
        admin: Address,
        base: u128,
        multiplier: u128,
        jump: u128,
        kink: u128,
    ) {
        require_admin(&env, &admin);
        if kink > SCALE_1E6 {
            panic!("invalid kink");
        }
        if base > 10_000_000u128 || multiplier > 10_000_000u128 || jump > 10_000_000u128 {
            panic!("invalid rate params");
        }
        env.storage()
            .persistent()
            .set(&DataKey::BaseRatePerYear, &base);
        env.storage()
            .persistent()
            .set(&DataKey::MultiplierPerYear, &multiplier);
        env.storage()
            .persistent()
            .set(&DataKey::JumpMultiplierPerYear, &jump);
        env.storage().persistent().set(&DataKey::Kink, &kink);
        bump_ttl(&env);
        ModelParamsUpdated {
            base_rate: base,
            multiplier,
            jump_multiplier: jump,
            kink,
        }
        .publish(&env);
    }

    pub fn propose_upgrade_wasm(env: Env, admin: Address, new_wasm_hash: BytesN<32>) {
        require_admin(&env, &admin);
        let execute_after = env
            .ledger()
            .timestamp()
            .saturating_add(UPGRADE_TIMELOCK_SECS);
        env.storage()
            .persistent()
            .set(&DataKey::PendingUpgradeHash, &new_wasm_hash);
        env.storage()
            .persistent()
            .set(&DataKey::PendingUpgradeEta, &execute_after);
        bump_pending_upgrade_ttl(&env);
    }

    pub fn upgrade_wasm(env: Env, admin: Address, new_wasm_hash: BytesN<32>) {
        require_admin(&env, &admin);
        bump_pending_upgrade_ttl(&env);
        let pending_hash: BytesN<32> = env
            .storage()
            .persistent()
            .get(&DataKey::PendingUpgradeHash)
            .expect("pending upgrade not set");
        let execute_after: u64 = env
            .storage()
            .persistent()
            .get(&DataKey::PendingUpgradeEta)
            .expect("pending upgrade eta not set");
        if pending_hash != new_wasm_hash {
            panic!("upgrade hash mismatch");
        }
        if env.ledger().timestamp() < execute_after {
            panic!("upgrade timelocked");
        }
        env.storage()
            .persistent()
            .remove(&DataKey::PendingUpgradeHash);
        env.storage()
            .persistent()
            .remove(&DataKey::PendingUpgradeEta);
        env.deployer().update_current_contract_wasm(new_wasm_hash);
    }

    fn utilization(cash: u128, borrows: u128, reserves: u128) -> u128 {
        if borrows == 0 {
            return 0;
        }
        let assets = cash.saturating_add(borrows);
        if reserves > assets {
            panic!("reserves exceed total assets");
        }
        let denom = assets - reserves;
        if denom == 0 {
            return 0;
        }
        let util = borrows.saturating_mul(SCALE_1E6) / denom;
        util.min(SCALE_1E6)
    }
}

fn ensure_initialized(env: &Env) {
    let persistent = env.storage().persistent();
    if persistent.get::<_, Address>(&DataKey::Admin).is_none()
        || persistent
            .get::<_, u128>(&DataKey::BaseRatePerYear)
            .is_none()
        || persistent
            .get::<_, u128>(&DataKey::MultiplierPerYear)
            .is_none()
        || persistent
            .get::<_, u128>(&DataKey::JumpMultiplierPerYear)
            .is_none()
        || persistent.get::<_, u128>(&DataKey::Kink).is_none()
    {
        panic!("model not initialized");
    }
}

fn assert_expected_admin(_env: &Env, _admin: &Address) {
    let expected_admin_str = expected_admin_config();
    let expected_admin = Address::from_string(&String::from_str(_env, expected_admin_str));
    if _admin != &expected_admin {
        panic!("unexpected admin");
    }
}

fn expected_admin_config() -> &'static str {
    if cfg!(any(
        test,
        all(debug_assertions, feature = "test-default-admin")
    )) {
        option_env!("JUMP_RATE_MODEL_INIT_ADMIN").unwrap_or(DEFAULT_INIT_ADMIN)
    } else {
        option_env!("JUMP_RATE_MODEL_INIT_ADMIN")
            .expect("JUMP_RATE_MODEL_INIT_ADMIN must be set at build time")
    }
}

fn require_admin(env: &Env, admin: &Address) {
    let stored: Address = env
        .storage()
        .persistent()
        .get(&DataKey::Admin)
        .expect("admin not set");
    bump_ttl(env);
    if stored != *admin {
        panic!("not admin");
    }
    admin.require_auth();
}

fn bump_ttl(env: &Env) {
    let persistent = env.storage().persistent();
    if persistent.has(&DataKey::Admin) {
        persistent.extend_ttl(&DataKey::Admin, TTL_THRESHOLD, TTL_EXTEND_TO);
    }
    if persistent.has(&DataKey::BaseRatePerYear) {
        persistent.extend_ttl(&DataKey::BaseRatePerYear, TTL_THRESHOLD, TTL_EXTEND_TO);
    }
    if persistent.has(&DataKey::MultiplierPerYear) {
        persistent.extend_ttl(&DataKey::MultiplierPerYear, TTL_THRESHOLD, TTL_EXTEND_TO);
    }
    if persistent.has(&DataKey::JumpMultiplierPerYear) {
        persistent.extend_ttl(
            &DataKey::JumpMultiplierPerYear,
            TTL_THRESHOLD,
            TTL_EXTEND_TO,
        );
    }
    if persistent.has(&DataKey::Kink) {
        persistent.extend_ttl(&DataKey::Kink, TTL_THRESHOLD, TTL_EXTEND_TO);
    }
}

fn bump_pending_upgrade_ttl(env: &Env) {
    let persistent = env.storage().persistent();
    if persistent.has(&DataKey::PendingUpgradeHash) {
        persistent.extend_ttl(&DataKey::PendingUpgradeHash, TTL_THRESHOLD, TTL_EXTEND_TO);
    }
    if persistent.has(&DataKey::PendingUpgradeEta) {
        persistent.extend_ttl(&DataKey::PendingUpgradeEta, TTL_THRESHOLD, TTL_EXTEND_TO);
    }
}

#[cfg(test)]
mod property_test;

#[cfg(test)]
mod test {
    use super::*;
    use soroban_sdk::testutils::Address as _;

    #[test]
    fn model_rates() {
        let env = Env::default();
        env.mock_all_auths();
        let admin = Address::from_string(&String::from_str(&env, DEFAULT_INIT_ADMIN));
        let id = env.register(JumpRateModel, ());
        let client = JumpRateModelClient::new(&env, &id);
        client.initialize(
            &20_000u128,
            &180_000u128,
            &4_000_000u128,
            &800_000u128,
            &admin,
        );
        let br_low = client.get_borrow_rate(&1_000u128, &100u128, &0u128);
        let br_high = client.get_borrow_rate(&10u128, &1_000u128, &0u128);
        assert!(br_high > br_low);
        let sr = client.get_supply_rate(&1_000u128, &500u128, &0u128, &100_000u128);
        assert!(sr > 0);
    }

    #[test]
    #[should_panic(expected = "unexpected admin")]
    fn initialize_rejects_unexpected_admin() {
        let env = Env::default();
        env.mock_all_auths();
        let admin = Address::generate(&env);
        let id = env.register(JumpRateModel, ());
        let client = JumpRateModelClient::new(&env, &id);
        client.initialize(
            &20_000u128,
            &180_000u128,
            &4_000_000u128,
            &800_000u128,
            &admin,
        );
    }

    #[test]
    fn set_params_updates_curve() {
        let env = Env::default();
        env.mock_all_auths();
        let admin = Address::from_string(&String::from_str(&env, DEFAULT_INIT_ADMIN));
        let id = env.register(JumpRateModel, ());
        let client = JumpRateModelClient::new(&env, &id);
        client.initialize(
            &20_000u128,
            &180_000u128,
            &4_000_000u128,
            &800_000u128,
            &admin,
        );
        let before = client.get_borrow_rate(&500u128, &500u128, &0u128);
        client.set_params(
            &admin,
            &10_000u128,
            &120_000u128,
            &3_000_000u128,
            &700_000u128,
        );
        let after = client.get_borrow_rate(&500u128, &500u128, &0u128);
        assert!(after != before);
    }

    #[test]
    #[should_panic(expected = "invalid reserve_factor")]
    fn get_supply_rate_rejects_invalid_reserve_factor() {
        let env = Env::default();
        env.mock_all_auths();
        let admin = Address::from_string(&String::from_str(&env, DEFAULT_INIT_ADMIN));
        let id = env.register(JumpRateModel, ());
        let client = JumpRateModelClient::new(&env, &id);
        client.initialize(
            &20_000u128,
            &180_000u128,
            &4_000_000u128,
            &800_000u128,
            &admin,
        );
        let _ = client.get_supply_rate(&1_000u128, &500u128, &0u128, &1_000_001u128);
    }
}
