use soroban_sdk::{contractevent, Address, BytesN};

use crate::storage::{PositionMode, PositionStatus};

#[contractevent(topics = ["admin_transfer_proposed"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdminTransferProposed {
    #[topic]
    pub current_admin: Address,
    #[topic]
    pub pending_admin: Address,
}

#[contractevent(topics = ["admin_transferred"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdminTransferred {
    #[topic]
    pub previous_admin: Address,
    #[topic]
    pub new_admin: Address,
}

#[contractevent(topics = ["position_created"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PositionCreated {
    #[topic]
    pub owner: Address,
    #[topic]
    pub position_id: u64,
    pub mode: PositionMode,
    pub status: PositionStatus,
}

#[contractevent(topics = ["position_removed"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PositionRemoved {
    #[topic]
    pub owner: Address,
    #[topic]
    pub position_id: u64,
    pub removed_at: u64,
}

#[contractevent(topics = ["position_collateral_added"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PositionCollateralAdded {
    #[topic]
    pub owner: Address,
    #[topic]
    pub position_id: u64,
    pub ptoken_amount: u128,
    pub collateral_ptokens: u128,
}

#[contractevent(topics = ["position_released"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PositionReleased {
    #[topic]
    pub owner: Address,
    #[topic]
    pub position_id: u64,
}

#[contractevent(topics = ["position_pool_replaced"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PositionPoolReplaced {
    #[topic]
    pub position_id: u64,
    #[topic]
    pub previous_pool: Address,
    pub new_pool: Address,
    pub new_pool_id: BytesN<32>,
}

#[contractevent(topics = ["close_residual"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CloseResidual {
    #[topic]
    pub position_id: u64,
    #[topic]
    pub owner: Address,
    pub repaid: u128,
    pub remaining_debt: u128,
    pub takeover_after: u64,
}

#[contractevent(topics = ["open_fee_reserved"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OpenFeeReserved {
    #[topic]
    pub position_id: u64,
    #[topic]
    pub vault: Address,
    pub fee_ptokens: u128,
}

#[contractevent(topics = ["close_fee_reserved"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CloseFeeReserved {
    #[topic]
    pub position_id: u64,
    #[topic]
    pub vault: Address,
    pub fee_underlying: u128,
}

#[contractevent(topics = ["margin_fees_distributed"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MarginFeesDistributed {
    #[topic]
    pub vault: Address,
    pub underlying: u128,
    pub fee_ptokens: u128,
}

#[contractevent(topics = ["liquidation_started"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LiquidationStarted {
    #[topic]
    pub position_id: u64,
    #[topic]
    pub liquidator: Address,
    pub owner: Address,
    pub debt_amount: u128,
    pub takeover_after: u64,
}

#[contractevent(topics = ["liquidation_swapped"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LiquidationSwapped {
    #[topic]
    pub position_id: u64,
    #[topic]
    pub liquidator: Address,
    pub collateral_underlying: u128,
    pub received_debt_asset: u128,
    pub takeover_after: u64,
}

#[contractevent(topics = ["liquidation_finished"])]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LiquidationFinished {
    #[topic]
    pub position_id: u64,
    #[topic]
    pub liquidator: Address,
    pub owner: Address,
    pub repaid: u128,
    pub bad_debt: u128,
    pub incentive: u128,
}
