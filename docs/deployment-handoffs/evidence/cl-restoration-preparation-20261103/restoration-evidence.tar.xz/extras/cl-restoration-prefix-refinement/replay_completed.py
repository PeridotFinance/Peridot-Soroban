import concurrent.futures,json,subprocess,sys
from pathlib import Path
base=Path('target/cl-restoration-prefix-refinement')
tasks=[]
for name in sys.argv[1:]:
 source=Path('target/cl-restoration-final-v7-'+name); verification=json.loads((source/'verification.json').read_text());out=base/name/'full-gate-replay';out.mkdir(parents=True,exist_ok=False)
 for profile,checks in verification['profiles'].items():
  dest=out/profile;dest.mkdir()
  for label,record in checks.items():tasks.append((name,profile,label,record,dest))
def replay(task):
 name,profile,label,record,dest=task;cmd=record['command'].copy();flag='--summary-json' if label=='financial' else '--output';expected=Path(cmd[cmd.index(flag)+1]);actual=dest/expected.name;cmd[cmd.index(flag)+1]=str(actual)
 with (dest/(label+'.log')).open('w') as log:run=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 report=json.loads(actual.read_text());assert report==json.loads(expected.read_text()),(name,profile,label);assert run.returncode==record['exit_code'],(name,profile,label,run.returncode)
 result={'run':name,'profile':profile,'label':label,'exact_report_match':True,'exit_code':run.returncode,'command':cmd};(dest/(label+'-replay.json')).write_text(json.dumps(result,indent=2)+'\n');return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for result in pool.map(replay,tasks):print(json.dumps(result),flush=True)
