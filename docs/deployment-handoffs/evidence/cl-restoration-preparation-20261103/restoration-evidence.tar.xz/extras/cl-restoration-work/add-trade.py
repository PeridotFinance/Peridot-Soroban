from pathlib import Path
p=Path('prototypes/cl-restoration-preparation/combined-repayment-tests.rs');s=p.read_text();start=s.index('fn compiled_combined_funded_liquidation_without_borrower_authorization()');i=s.index('let (paid, seized)',start);s=s[:i]+'crate::transaction_evidence::set_restoration_trade_actor(&f.user);\n    '+s[i:];p.write_text(s)
p=Path('prototypes/cl-restoration-preparation/restoration.rs');s=p.read_text().replace('use soroban_sdk::Symbol;','use soroban_sdk::{Symbol,IntoVal,Map};')
s=s.replace('thread_local! {pub static OVERRIDE:', 'thread_local! {static TRADE_ACTOR:RefCell<Option<String>>=const{RefCell::new(None)}; pub static OVERRIDE:')
s=s.replace('struct ProfileGuard(String);','pub fn set_trade_actor(a:&Address){TRADE_ACTOR.with(|v|*v.borrow_mut()=Some(strkey(a)));}\nstruct ProfileGuard(String);')
s=s.replace('let sdk=sdk_after(e,&state,warm,name);','let sdk=sdk_after(e,&state,if final_tx["success"]==true{&final_tx}else{warm},name);')
s=s.replace('let final_tx=on_snapshot(e,&state,to,name,args,external);append', '''let mut intervening=Value::Null;
  if name=="liquidate_funded_v3" {
   if let Some(actor)=TRADE_ACTOR.with(|v|v.borrow().clone()) {
    let pool=Address::from_str(e,&crate::resource_profile::contract_address("aquarius").unwrap());
    let trader=Address::from_str(e,&actor);let amount=5_000_000_000u128;
    let quote=on_snapshot(e,&state,&pool,"estimate_swap",&(0u32,1u32,amount).into_val(e),None);
    if quote["success"]!=true || quote["limits_pass"]!=true{return Err("intervening quote failed selected limits".into());}
    let value=ScVal::from_xdr_base64(quote["return_value_xdr"].as_str().unwrap(),Limits::none()).unwrap();
    let out_min=u128::try_from_val(e,&value).unwrap();
    let trade=on_snapshot(e,&state,&pool,"swap",&(trader.clone(),0u32,1u32,amount,out_min).into_val(e),Some(&trader));
    if trade["success"]!=true || trade["limits_pass"]!=true{return Err("intervening swap failed selected limits".into());}
    let original_hash=data_hash(&state);apply_host_changes(&mut state,&trade);
    assert_ne!(data_hash(&state),original_hash,"pool trade must actually change state");
    intervening=json!({"kind":"independent funded trader after preparation, before fresh financial simulation","quote":quote,"transaction":trade,"operator_fee_includes_trade":false,"third_party_fee":trade["fees"]["total"],"snapshot_after_trade_sha256":snap_hash(&state)});
   }
  }
  let final_tx=on_snapshot(e,&state,to,name,args,external);append''')
s=s.replace('"profile":profile,"operation":name,','"profile":profile,"operation":name,"intervening_pool_trade":intervening,')
s=s.replace('append("CL_RESTORE_SDK_REPORT",&row);row','if result.is_ok(){row["reward_conservation"] = conservation(&fresh);}\n append("CL_RESTORE_SDK_REPORT",&row);row')
p.write_text(s)
