import subprocess
from pathlib import Path
runs=['cl-restoration-probe-v2','cl-restoration-probe-v2-funded','cl-restoration-probe-v3-trade','cl-restoration-combined-v4','cl-restoration-final-v5-combined','cl-restoration-final-v5-combined-retry','cl-restoration-final-v5-open-close','cl-restoration-final-v5-liquidations','cl-restoration-final-v5-pending','cl-restoration-diagnostic-v6-funded']+['cl-restoration-final-v7-'+n for n in ['combined','open-close','liquidations','pending']]
command=['python3','prototypes/cl-restoration-preparation/package.py','--build','target/cl-restoration-final-v7-build','--clean-build','target/cl-restoration-clean-build','--output','target/cl-restoration-publication-v1']
for run in runs:command+=['--run','target/'+run]
files=[]
for directory in ['cl-restoration-work','cl-restoration-journey-checker-tests','cl-restoration-postcondition-checker-tests','cl-restoration-prefix-refinement','cl-restoration-v7-open-close-independent']:
 files += [p for p in (Path('target')/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix in {'.log','.json','.jsonl','.txt','.md','.rs','.py','.patch','.wasm'} and p.name not in {'publication.log'}]
for directory in ['cl-restoration-probe-v2-build','cl-restoration-probe-v3-build','cl-restoration-probe-v4-build','cl-restoration-final-v5-build','cl-restoration-diagnostic-v6-build']:
 build=Path('target')/directory
 files += [build/'build-manifest.json',build/'harness/Cargo.toml',build/'harness/Cargo.lock']
 files += list((build/'harness/src').glob('*.rs'))
for file in sorted(set(files)):
 assert file.exists(),file
 command += ['--extra',str(file)]
Path('target/cl-restoration-work/publication-command.json').write_text(__import__('json').dumps(command,indent=2)+'\n')
raise SystemExit(subprocess.run(command).returncode)
