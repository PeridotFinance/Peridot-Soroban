# Larger-history checkpoint result

Source: contracts/cl-share-pool-facade/src/history_scale_tests.rs. No runtime contract changes. The lead owns test.rs module wiring and proof-map integration.

Command from repository root:

```sh
bash target/cl-next-history/run.sh captured-final-v2
python3 target/cl-next-history/summarize.py target/cl-next-history/captured-final-v2
```

The runner records exact hashes for the previous checkpoint WASMs, Aquarius, captured configuration, selected profile and test source in captured-final-v2/input-hashes.json. It uses the official host29 runtime with the validated protocol29 captured cost model and enforced captured-network limits. This local assessment predates the lead's fresh build including complete-open reserve changes; the frozen full runner supplies definitive integrated and archive results.

Both compiled tests passed in 433.60 seconds. 411 invocation rows and 502 unsigned transaction records were captured. check_budget.sh returned 1: invocation PASS; lifecycle FAIL (isolated suite has no completed full lifecycle manifest/required flow coverage); transaction FAIL (full proof-to-call mapping absent); checkpoint FAIL; release approval false. Every provided invocation passed captured limits. These are not all required lifecycle flows and must not stand in for them.

| Assessed operation | Max CPU | Max memory bytes | Max SDK entries | Max writes | Existing internal threshold comparison |
| --- | ---: | ---: | ---: | ---: | --- |
| 64-owner historical emergency exit | 138682960 | 14125779 | 75 | 24 | CPU fails |
| Historical settlement among 64 owners | 5037574 | 2210162 | 16 | 6 | These ceilings pass |
| Later claim over 8 outages | 18331842 | 6198486 | 33 | 12 | These ceilings pass |
| Funded exit with both reward calls failing | 98042036 | 15080203 | 197 | 50 | SDK entries fail |
| Governed segment attribution | 2137077 | 1675848 | 11 | 4 | These ceilings pass |
| Governed exited-beneficiary settlement | 3922429 | 1831546 | 17 | 6 | These ceilings pass |

The internal column compares quantities from captured-network executions against unchanged internal ceilings; it is not an internal-policy acceptance run. The lead's full runner performs both profiles. Memory stays below 41,943,040 bytes for these assessed flows, but this does not establish production state-size or price-range bounds.

Unsigned target-runtime maxima: 128,362,535 CPU, 12,210,991 memory bytes, 149 unique footprint entries, 13,964 envelope bytes. Maximum complete fee estimate 7,178,664 stroops, including 7,046,224 rent. Funded transactions include 532 authorization-XDR bytes; account signatures are not supplied or verified. No archive rows occur in this isolated run; the lead's CL_TRANSACTION_ARCHIVE_ROLE=vault rerun covers actual historical-key restoration and corresponding fees separately.

The 64-owner test constructs 383 immutable checkpoints via real compiled calls (including 128 additional ownership changes). It performs 8 complete exits during 8 claim outages. All 64 historical beneficiaries settle the earliest interval after those exits; corresponding exited holders incrementally settle the seven later intervals. Exact scaled conservation: received174107, paid0, pending27167, summed fractions43818815677757402556, historical backing in quarantine bucket146896, rounding181184322242597444. There are no missing boundaries in this test: the remaining backing is attributable but not yet settled, distinct from unresolved rewards.

The custody test constructs 8 actual margin positions and performs 8 funded repayments/seizures while both venue claim and pending view fail. It records16missing boundaries. Before governed attribution: received1460655, paid0, pending192191, fractions999999999421626200, quarantine1268463, rounding578373800. One interval is explicitly governed after published controlled-replay evidence and the86400-second delay;192192reward units are credited entirely to the borrower who has since exited all receipt/margin custody, zero to the liquidator for that interval. Afterwards: pending384383, quarantine1076271, same fractions/rounding, exact scaled conservation. Seven intervals remain unresolved; attempted settlement rejects with complete ledger rollback. Repeated legitimate settlement returns0. Forced liquidation never waives rewards.

Published controlled-replay evidence:
`captured-final-v2/governed/history-scale-interval-1.json`
SHA256 `145b552e091cd9c8accac3f1c9ee34a4ed2a3943bc25bc6e2f684002596bafd3`.
This does not establish live missing-boundary evidence or automatically verified accrual. See ATTRIBUTION.md for the records governance needs and why unavailable evidence leaves indefinite quarantine.

Earlier evidence is preserved: captured-initial was interrupted and explicitly labeled diagnostic after independent review found reward_account was mutating assessed state in an assertion helper. The final helper clones the ledger for every assertion/index query, preventing settlement or TTL warming of measured state. captured-cloned-inspection and captured-final preserve ordinary SDK API compile failures. captured-final-v2 is the completed passing run. No resource limits or transaction stages changed.
