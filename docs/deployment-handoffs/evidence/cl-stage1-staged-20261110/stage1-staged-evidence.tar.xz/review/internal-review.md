Internal reviewer, not Fable; read-only source and evidence review.

Verified nine V3/V4 resource rows and real receipt/vault authorization. Named close
allocation rule is sound in the inspected path. Found mint pricing used convergence LP
composition rather than actual backing. Lead corrected it in final buildv4.

Correction verified: fresh actual fee-inclusive snapshot used once at mint; actualNAV
19,992,879 versus convergence19,990,415; minted199,858,894 rather than199,883,529.
Investment now preserves both valuations; cap checks actual backing. Final13 tests pass;
investment95,217,621 unsigned CPU,4,782,379 remaining. Global missing gates still fail.

Unresolved: reward-outage exit after mint; cancellation only unlocks shares/refundsreserve;
legacyentrypointcompatibility; payoutrollback; signedauth; coldrestoration; boundedhistories.
No assertion of Fable review, live capacity or production safety.
