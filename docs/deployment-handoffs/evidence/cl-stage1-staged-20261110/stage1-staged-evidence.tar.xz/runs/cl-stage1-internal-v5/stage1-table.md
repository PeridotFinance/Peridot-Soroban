|Transaction|CPU SDK|CPU unsigned host|Memory max bytes|SDK entries|Unique keys|Writes|Result|
|---|---:|---:|---:|---:|---:|---:|---|
|stage1_prepare|7132049|7489621|4691612|15|16|4|PASS|
|stage1_fund|3682897|3909468|3096813|14|15|6|PASS|
|stage1_convert|30634844|31234483|6617565|22|22|8|PASS|
|stage1_fee_checkpoint_cash_mint|74088434|75014006|9178188|50|50|19|PASS|
|stage1_keeper_investment|92348352|93065796|11271433|43|43|18|PASS|
|stage1_prepare_close|2642853|2803494|2858175|12|13|4|PASS|
|stage1_withdraw_in_kind|78322264|78912579|10132141|52|53|26|PASS|
|stage1_withdraw_for_conversion|77400033|78038615|10132141|50|50|24|PASS|
|stage1_optional_close_conversion|23305584|23856199|6432544|23|23|9|PASS|
